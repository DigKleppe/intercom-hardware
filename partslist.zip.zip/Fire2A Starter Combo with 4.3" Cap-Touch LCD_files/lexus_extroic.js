var liveprice_getCustomMethodsOfTheme = (function($){
	return function( extension ) {
		
		var methods = {
			
			init : function() {
	
			},
			
			updatePrice_before : function() { // get the quantity to do not execute recalculation by interval check of the quantity changes
				
			},
			
			getContainer : function() {
				
			},
			
			getElementsToUpdatePriceOnClick : function() {
				return extension.getElement('.add-up, .add-down');
			},
			
			getSelectorForElementsToUpdatePriceOnClick : function() { // to use for dynamic elements by on(event, selector, ...)
				
			},
			
			getElementsToAnimateOnPriceUpdate : function() { // returns $ object or array of $ objects
				return extension.getElement('.product-info .price');
			},
			
			getRequestURL : function() {
				
			},
			
			setPriceHTML : function( json ) {
				
				let $price_element = extension.getElement('.product-info .price');
				if ( $('body').is('.page-product') ) {
					$price_element.html(json.htmls.html);
				} else {
					extension.getElement('.product-info .price').html(json.htmls.quickview);
				}
				if ( $price_element.next().is('.list-unstyled') && $price_element.next().next().is('.list-unstyled') ) {
					$price_element.next().replaceWith(json.htmls.tax_and_discounts);
				}
			},
			
		};
		
		return methods;
	};
}
)(jQuery);
// extension.getElement
// extension.updatePrice