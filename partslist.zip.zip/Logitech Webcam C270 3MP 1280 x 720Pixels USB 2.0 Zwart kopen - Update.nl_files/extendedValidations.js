Validation.add('validate-postbus','Postbus is niet toegestaan',function(field_value){
    var str = field_value;
    str = str.replace(/\s+/g, '');
    var res = str.toLowerCase();

    var index;
    var options = ["postbus","postbu","postbu","postb","pb"];
    var n;
    var found = false;

    for (index = 0; index < options.length; ++index) {
        n = res.includes(options[index]);
        if(n == true){
            found = true;
        }
    }

    if(found == false){
        return true;
    }
    return false;
});
Validation.add('validate-postcode', 'Please enter a valid zip code. For example 90602 or 90602-1234.', function(v) {
    return Validation.get('IsEmpty').test(v) || /(^\d{4}$)|(^\d{5}$)|(^\d{5}-\d{4}$)/.test(v) || /^[1-9][0-9]{3}?(?!sa|sd|ss)[a-z]{2}$/i.test(v);
});
