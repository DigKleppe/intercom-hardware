//$(window).load(function() {
$(function() {	
        //initial mit 1. Bild aufrufen, versteckt den Rest
        changeImage(1);        
        $('#gallery').show();
    
	if (!($.browser.msie && parseInt($.browser.version, 10) < 7))  {
                //XXL Image als Galerie
                $('.xxl').magnificPopup({            
                    type: 'image',
                    gallery: {
                        enabled: true,
                        tCounter: '%curr% / %total%'
                    },
                    image: {
                        titleSrc: 'title',
                        verticalFit: true,
                        tError: 'Image could not be loaded.'
                    }
                });
                
                //Video Popup (FLV/MP4/OGG/WEBM)
                $('.video').magnificPopup({     
                    
                    type: 'iframe',
                    gallery: {
                        enabled: true,
                        tCounter: '%curr% / %total%'
                    },
                    iframe: {
                        patterns: {
                            local_video: {       
                            index: 'index.php?ACTION=413',
                            id: 'ID=',                         
                            src: 'index.php?ACTION=413&VIEW=noframe&INLINE=true&ID=%id%'
                          }
                        },
                        tError: 'Video could not be loaded.'
                    }     
                });
                
                var mySwiper = new Swiper($('.thumbnail-gallery'),{
                //Your options here:
                    mode:'horizontal',
                    loop: false,
                    slidesPerView: 3,
                    slidesPerGroup: 1,
                    //loopAdditionalSlides: 2,
                    keyboardControl: true,
                    mouseWheelControl: true,
                  //  createPagination: true,
                    grabCursor: true,
                    //centeredSlides: true,
                    DOMAnimation: true,
                    navigation: {
                                nextEl: '.swiper-button-next',
                                prevEl: '.swiper-button-prev',
                              }
                    
                });
        if ($.browser.msie && $.browser.version.slice(0,1) == "8"){
              ie8Fix();
         } 
                
	}
    
});

//damned IE8 !
function ie8Fix(){     
     var old_url = $('.video').attr('href');
     var height = 508;
     $('.video').attr('href',old_url+'&H='+height);
} 

function changeImage(current) {
//	var imagesNumber = parseInt(document.getElementById('product_images').getAttribute('data-count'));
	var imagesNumber = $('.xxl').length;
	
	for (i=1; i<=imagesNumber; i++) {	
		if (i == current) {
			document.getElementById("normal" + current).style.display = "block";
                        
		} else {
			document.getElementById("normal" + i).style.display = "none";
		}
	}
        
       
}