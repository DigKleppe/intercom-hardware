// Hack f�r die die das cdn-reichelt.de nicht zugelassen haben
var cdn = true;
var searchselected = false;

/**
 * Plugin flyingBasket
 * Zeigt dan aktuellen Warenkorb in einer vereinfachten �bersicht
 * 
 * @param {type} $
 * @param {type} window
 * @param {type} document
 * @param {type} undefined
 * @returns {undefined}
 */
;(function ( $, window, document, undefined ) {
    "use strict";
 
    var pluginName = 'flyingBasket',
        defaults = {
            animatespeed: 300,
			delaytime	: 200,
			limit		: 5, // max shown articles
			lockthing	: true,
			bastimer	: null
        };    
 
	
	var bindBasket = function(object) {
		$(object.element).bind('mouseleave', function(){object.options.bastimer = 'wech';})
					.bind('mouseover', function() {
					if ($('#flyingBasket').length === 0 && object.options.lockthing === true) {
						
							// loadingdiv
						object.options.loadingtimer = setTimeout(function(){$(object.element).append('<div class="loading_div greenBorder" style="width: 300px; top: 30px; right: 0;"> </div>');}, object.options.delaytime);
						$(object.element).bind('mouseleave', function(){
									 object.options.mousein = false;
									 clearTimeout(object.options.loadingtimer);
									 $(".loading_div").remove();

								});
						object.options.lockthing = false;
                        var SIDparam = '';
                        if($.getUrlVar('SID') !== '' && $.getUrlVar('SID') !== undefined) {
                            SIDparam = '&SID=' + $.getUrlVar('SID');
                        }
						$.ajax({
								url: "?ACTION=514&ID=13&LIMIT=" + object.options.limit + SIDparam,
								contentType : "application/json; charset=ISO-8859-1",
								dataType    : "json",
								async       : true,
								cache       : false,
								processData : false,
								success     : function(data, textStatus){

									// Build and get the basket
									$(object.element).prepend(createBasket(data));

									// Do something fantastic cool Animation
									animateFlyingBasket(object);
								}
						});
					}		
			});
	};
	
	/*
	* Creating and returning the flying BAsket
	* 
	*  @data       - picked JSON-Data 
	*  @callback   - optional an callback function
	*  @return     - basket as an html-snipet
	*/
	var createBasket = function(data) {
        var choosedivclass = 'choosediv';
        if($("#StatusBar_02").length > 0){
            choosedivclass = 'chsdv';
        }
		var basketDiv = "<div id='flyingBasket' class='" + choosedivclass + "'><ul>";
		var articlecount = data[0].articles.length;
		if (articlecount > 0) {
			$.each(data[0].articles, function(i, item) {
				basketDiv += "<li class='article clearfix'>";
				basketDiv += "<a style='background: url(" + item.pic + ") no-repeat' href='" + item.link + "'>";
				basketDiv += "<span class='artno'>" + item.artnr + "</span>";
				basketDiv += "<span class='quantity'>" + " " + item.quantity + " x" + "</span></span>";
				basketDiv += "<span class='descr'>" + item.description + "</span>";
				basketDiv += "</a>";
				basketDiv += "</li>";
			});
		} else {
			basketDiv += "<li id='infoline'>" + data[2].lang[0].EMPTYBASKET + "</li>";
		}
		// more articles then limit
		if (data[3].hidden !== undefined) {
			basketDiv += "<li id='infoline'>" + data[3].hidden + data[2].lang[0].MOREARTICLES + "</li>";
		}
		basketDiv+= "</ul>";
		basketDiv+= "<p id='links' class='clearfix'>";
		basketDiv+= "<a href='" +  data[1].links[0].basket[0].url + "'>" + data[1].links[0].basket[0].text + "</a>";
		if (data[3].payable === 1) {
			basketDiv+= "<a href='" +  data[1].links[1].checkout[0].url + "'>" + data[1].links[1].checkout[0].text + "</a>";
		}
		basketDiv+= "</p>";
		basketDiv+= "</div>";
		// optional
		return basketDiv;
	};
	
	/*
	* animate the little cool flying basket to rise the conversion rate :)
	* 
	*  @data       - some delivered data from farfar away 
	*  @callback   - optional an callback function
	*  @return     - must have to work with jquery 
	*/
   var animateFlyingBasket = function(object) {
	   var $flyingBasket = $('#flyingBasket');
	   // resize Basket when resizing window
//            $flyingBasket.css("max-height", $(window).height());
//            $(window).resize(function() {
//                $flyingBasket.css("max-height", $(window).height());
//            });
	   if (object.options.bastimer != 'wech') {
		   $flyingBasket.fadeIn(object.options.animatespeed);
		   $(".loading_div").fadeOut(200).remove();
	   } 
	   object.options.lockthing = true;
	   $(object.element).unbind('mouseover mouseout')
			   .click(function(){clearTimeout(object.options.bastimer);})
			   .hover(
		   function() {
			   clearTimeout(object.options.bastimer);
			   object.options.bastimer = setTimeout(function(){$flyingBasket.fadeIn(object.options.animatespeed);}, object.options.delaytime);
		   },
		   function() {
			   clearTimeout(object.options.bastimer);
			   object.options.bastimer = setTimeout(function(){$flyingBasket.fadeOut(object.options.animatespeed);}, object.options.delaytime);
		   }
	   );	

	   return this;
   };
 
    function Plugin( element, options ) {
 
        this.element = element;
        this.options = $.extend( {}, defaults, options) ;
 
        this._defaults = defaults;
        this._name = pluginName;
 
        this.init();
 
    }
 
    Plugin.prototype.init = function () {
		bindBasket(this);
    };
	
    Plugin.prototype.reset = function () {
		$('#flyingBasket', this.element).remove();
		bindBasket(this);
    };
	
    $.fn[pluginName] = function ( options ) {
        return this.each(function () {
            if (!$.data(this, 'plugin_' + pluginName)) {
                $.data(this, 'plugin_' + pluginName, 
                new Plugin( this, options ));
            }
        });
    }
})( jQuery, window, document );

/**
 * Nur Nummern? Eventuell Obsolete?
 * 
 * @param {type} sender
 * @returns {undefined}
 */
function Acceptnumber(sender){
	if(window.event){
    	key = window.event.keyCode;
        if(key == 13){
        	document.contentform.submit();
	    }
    	if (!((key > 47) && (key < 58))){
        	window.event.keyCode=0;
        }
    }else{
      sender.value=sender.value.replace(/[^0-9]/,"");
    }
}

/**
 * Sauberere M�glichkeit f�r Document.Write
 * Geutzt f�r Shopauskunft
 * 
 * @type Function|Function
 */
var domWrite = (function(){
var dw = document.write,
myCalls = [],
t = '';
function startnext(){
if ( myCalls.length > 0 ) {
if ( Object.watch ) console.log( 'next is '+myCalls[0].f.toString() );
myCalls[0].startCall();
}
}
function evals( pCall ){
var scripts = [],
script,
regexp = /<script[^>]*>([\s\S]*?)<\/script>/gi;
while ((script = regexp.exec(pCall.buf))) scripts.push(script[1]);
scripts = scripts.join('\n');
if (scripts) {
eval(scripts);
}
}
function finishCall( pCall ){
pCall.e.innerHTML = '';
var div = document.createElement('div');
div.innerHTML = pCall.buf;
pCall.e.appendChild(div);
evals( pCall );
document.write=dw;
myCalls.shift();
window.setTimeout( startnext, 50 );
}
function testDone( pCall ){
var myCall = pCall;
return function(){
if ( myCall.buf !== myCall.oldbuf ){
myCall.oldbuf = myCall.buf;
t=window.setTimeout( testDone( myCall ), myCall.ms );
}
else {
finishCall( myCall );
}
}
}
function MyCall( pDiv, pSrc, pFunc ){
this.e = ( typeof pDiv == 'string' ?
document.getElementById( pDiv ) :
pDiv ),
this.f = pFunc || function(){},
this.stat = 0,
this.src = pSrc,
this.buf = '',
this.oldbuf = '',
this.ms = 100,
this.scripttag;
}
MyCall.prototype={
startCall: function(){
this.f.apply( window );
this.stat=1;
var that = this;
document.write = (function(){
var o=that,
cb=testDone( o ),
t;
return function( pString ){
window.clearTimeout( t );
o.stat=2;
window.clearTimeout(t);
o.oldbuf = o.buf;
o.buf += pString;
t=window.setTimeout( cb, o.ms );
};
})();
var s=document.createElement('script');
s.setAttribute('language','javascript');
s.setAttribute('type','text/javascript');
s.setAttribute('src', this.src);
document.getElementsByTagName('head')[0].appendChild(s);
}
}
return function( pDiv, pSrc, pFunc ){
var c = new MyCall( pDiv, pSrc, pFunc );
myCalls.push( c );
if ( myCalls.length === 1 ){
startnext();
}
}
})()

/**
 * Plugin addToBasket
 * 
 * Artikel werden ohne neuladen der Seite �ber einen Ajax-Requst in den Warenkorb gelegt.
 * Die Seite passt sich anhand der zur�ckgegebenen Daten an und gibt dem Kunden eine R�ckmeldung.
 * 
 * @param {type} $
 * @param {type} window
 * @param {type} document
 * @param {type} undefined
 * @returns {undefined}
 */
;(function ( $, window, document, undefined ) {
    "use strict";
 
    var pluginName = 'addToBasket',
        defaults = {
            animatespeed: 400
        };    
 
	/*
	 * 
	 * @param {type} input
	 * @returns {undefined}
	 */
    var setEvents = function(input, options) {
//		alert($(element).attr('type') + '55');
//		
		// Inputs +- neben Zahlenfeld in myreichelt
		$("button[name = 'change']", $(input)).click(function(){
			var value = $(this).val(); 
			$("input[type = 'number']", $(this).parent()).val(function(i, oldval){
				if (value === '-'){
					if (oldval === '0'){
						return oldval;
					} else {
						return --oldval;
					}
				} else {
					return ++oldval;
				}
			}).trigger('focusout');
            return(false);
        });

		switch ($(input).attr('type')) {
			// Input for amount
            case 'number':
			case 'text' : 
				if (window.navigator.userAgent.indexOf("MSIE ") > 0) {
					$(input).keydown(function(e) {
								if(e.keyCode === 13) {
									e.preventDefault ? e.preventDefault() : e.returnValue = false;
									submitBasket(input, options);
								}});
				} else {
					$(input).keypress(function(e) {
								if(e.keyCode === 13) {
									e.preventDefault ? e.preventDefault() : e.returnValue = false;
									submitBasket(input, options);
								}});
				}
					$(input).focusout(function(){
							submitBasket(input, options);
							return false;
						});
				break;
			// Input "add to cart"
                        case 'submit':
			case 'image': $(input).click(function(){
								submitBasket(input, options);
								return false;
							});
				break;
			default:
				break;
		}
		return true;
    };
	
	/**
	 * �bermittelt zugef�gten Artikel und bekommt notwendige Daten f�r updates zur�ck
	 * @argument {Selection} element : In den Warenkorb legendes Inputelement
	 * @returns {undefined}
	 */
	var submitBasket = function(element, options) {
		var pos                 = $(element).parent().parent().parent().attr('pos');
                if(pos == undefined){
        		pos                 = $(element).parent().parent().parent().parent().attr('pos');
                    }
		var type		= $(element).attr('type');
		var artid		= $(element).attr('name').replace(/[^0-9]*/g,'');
		var anzahl		= $('input[name="anzahl\['+ artid +'\]"]').val();
		var anzahl_alt	= $('input[name="anzahl_alt\['+ artid +'\]"]').val();
		if ((anzahl === '' || anzahl === undefined ) && type !== 'text') {
			anzahl = 1;
		} 
		if (anzahl_alt === undefined) {
			anzahl_alt = 0;
		}
		if (anzahl !== '' && anzahl !== anzahl_alt && (anzahl >=0 || anzahl < 0) ) {
//				alert(anzahl);
            var SIDparam = '';
            if($.getUrlVar('SID') != '' && $.getUrlVar('SID') !== undefined) {
                SIDparam = '&SID=' + $.getUrlVar('SID');
            }
            if($.getUrlVar('WKID') != '' && $.getUrlVar('WKID') !== undefined) {
                SIDparam = '&WKID=' + $.getUrlVar('WKID');
            }
            
            if(pos != undefined){
                if($.getUrlVar('SEARCH') != '%252A' && $.getUrlVar('SEARCH') != '' && $.getUrlVar('SEARCH') != undefined){
                    var trst='&trstct=pos_'+pos;
                }else{
                    var trst='&trstct=pol_'+pos;
                }
            }else{
                var trst='';
            }
            var urlparams = '&Uebernehmen[' + artid + ']=' + anzahl + '&anzahl[' + artid + ']=' + anzahl + '&ARTID=' + artid + '&anzahl_alt[' + artid + ']=' + anzahl_alt + SIDparam+trst;
//            var params = {
////                            "Uebernehmen['" + artid + "']":anzahl,
////                            TABLENAME:$seofield.attr('data-tablename'),
////                            COLUMNAME:$seofield.attr('data-columnname'),
////                            FIELDID:$seofield.attr('data-id'),
////                            FIELDCONTENT:content
//                              SID:$.getUrlVar('SID')
//                        };
            
			$.ajax({
				url: "?ACTION=514&ID=12"+ urlparams,
//                data: params,
                type: "POST",
				contentType : "application/json; charset=ISO-8859-1",
				dataType    : "json",
				cache       : false,
				async       : true,
				processData : false,
				success: function(updateData, textStatus) {
//					alert('fertig!!');
					updateScreen(updateData, element, options);
					sendStatistic(updateData, anzahl - anzahl_alt, options);
					informUser(updateData, anzahl - anzahl_alt, element, options);
				}			
			});
		};
        
        if (typeof updateDelayView !== "undefined") {
            updateDelayView();
        }
        
		return true;
	};
	
	/**
	 * Blockiert Screen da syncronesAjax Eingaben blockiert
	 * 
	 * @param {type} whattodo
	 * @param {type} message
	 * @returns {undefined}
	 */
	var blockScreen = function(whattodo, message, options) {
		if ($('#blockingDiv').length === 0) {
			$('body').append('<div id="blockingDiv"></div>');
		}
		var $blockingdiv = $('#blockingDiv');
		switch (whattodo) {
			case 'block':
				$blockingdiv.fadeIn(options.animatespeed);
				break;
			case 'release':
				setTimeout(function(){$blockingdiv.fadeOut(options.animatespeed);}, 1000);
//				$blockingdiv.fadeOut(options.animatespeed);
				break;
			default:
				break;
		}
		
	}
	
	/**
	 * Updatet die HTML Elemente der Seite (briefbasket ect.)
	 * 
	 * @param {type} updateData
	 * @param {type} element
	 * @returns {_L7.$.fn.addToBasket}
	 */
	var updateScreen = function(updateData, element, options) {
		// kleiner Inputwarenkorb
		if(!$(element).attr('name').match('Insert')){
			var type		= $(element).attr('type');
			var artid		= $(element).attr('name').replace(/[^0-9]*/g,'');
			var anzahl		= $('input[name="anzahl\['+ artid +'\]"]').val();
			if (anzahl === '' && type !== 'text') {
				anzahl = 1;
			} 
			// update inputs
			$('input[name="anzahl\['+ artid +'\]"]').val(anzahl);
			$('input[name="anzahl_alt\['+ artid +'\]"]').val(anzahl);
			// update image
			var $image = $('input[name="Uebernehmen\['+ artid +'\]"]');
            if($image.attr('src') != undefined){
                if (anzahl === '0') {
                    $image.attr('src', $image.attr('src').replace(/in-den-warenkorb_2/g,'in-den-warenkorb_1'));
                } else {
                    $image.attr('src', $image.attr('src').replace(/in-den-warenkorb_1/g,'in-den-warenkorb_2'));
                }
            }
		};
		// update statusbar
		$('#basketamount').text(updateData['count']);
		$('#basketsum').text(updateData['price']);
		$('#del_costs').text(updateData['del_costs']);
		if ($('#flyingBasket').length > 0) {
			$('#basket').data('plugin_flyingBasket').reset();
		}

		return this;
	};
	
	/**
	* Versendet Statistiken
	* 
	* @param {JSON} data 
	* @param {type} anzahl
	* @returns {true}
	*/
   var sendStatistic = function(data, anzahl, options) {
	   //webtrekk: Nur positive Zahlen und wenn wt definiert
//	   if (anzahl > 0 && typeof wt !== 'undefined') {
//		   wt.sendinfo({product : encodeURI(data['article']),
//						productQuantity : anzahl,
//						productCost : (data['preis'] * anzahl),
//						productStatus : 'add'
//					});
//	   }
       // Facebook tracking
	    if (anzahl > 0 && typeof fbq !== 'undefined') {
            fbq('track', 'AddToCart', {
              content_ids: [data['article']],
              content_type: 'product',
              value: data['preis'],
              currency: data['currency'] 
            });
        }
       
	   return true;
   }
   
   /**
	* Kleines Div zur R�ckmeldung an den Kunden
	* 
	* @param {type} data
	* @param {type} anzahl
	* @param {type} element
	* @returns {_L7.$.fn.addToBasket}
	*/
   var informUser = function(data, anzahl, element, options) {
	   // Eingabe zahl und click  w�rde 2 Feedbacks verursachen
	   if($('#feedback' + data['artid']).length < 1) {
			var infodiv	 = '<div id="feedback' + data['artid'] + '" class="basketFeedback greenBorder">';
			infodiv += '<span id="infotext">' + data['lang_inbasket'] + '</span>';
			infodiv += '<p>';
			infodiv += '<span id="infoart">' + data['article'] + '</span>';
			infodiv += '<span>';
			infodiv += data['lang_amount'] + ' ';
	 //			if (anzahl > 0 ) {
	 //				infodiv+= ' +';
	 //			}
			infodiv+= anzahl + '</span></p></div>';

			var $parent = $(element).parent().parent();

//			$(':input[type = image]', $parent).last().after(infodiv);
			$(':input[type = submit]', $parent).last().after(infodiv);

			$('#feedback' + data['artid']).fadeIn(options.animatespeed,function(){$('#feedback' + data['artid'])
										 .delay(1000)
										 .fadeOut(options.animatespeed, function(){$('#feedback' + data['artid'])
										 .remove();
								 return this;});
							 return this;});
	   }
	   return true;
	};
		
    function Plugin( element, options ) {
        this.element = element;
        this.options = $.extend( {}, defaults, options);
 
        this._defaults = defaults;
        this._name = pluginName;
 
        this.init();
 
    }
    Plugin.prototype.init = function () {
		setEvents(this.element, this.options);
    };
 
    $.fn[pluginName] = function ( options ) {
        return this.each(function () {
            if (!$.data(this, 'plugin_' + pluginName)) {
                $.data(this, 'plugin_' + pluginName, 
                new Plugin( this, options ));
            }
        });
    };
})( jQuery, window, document );


/**
 * jQuery lightweight plugin boilerplate
 * Original author: @ajpiano
 * Further changes, English comments: @addyosmani
 * More further changes, German translation: @klarstil
 * Licensed under the MIT license
 */
;(function ( $, window, document, undefined ) {
    "use strict";
 
    var pluginName = 'overLayer',
        defaults = {
            propertyName: "value"
        };    
 
    var privateMethod = function() {
    };
 
    function Plugin( element, options ) {
 
        this.element = element;
        this.options = $.extend( {}, defaults, options) ;
 
        this._defaults = defaults;
        this._name = pluginName;
 
        this.init(this.options);
 
    }
 
    Plugin.prototype.init = function (options) {
//		alert(this.options.requesturl);
		$(this.element).click(function(e){
			$.ajax({
				url: options.requesturl,
				contentType : "application/x-www-form-urlencoded; charset=ISO-8859-1",
				dataType    : options.dataType,
				cache       : false,
				async       : true,
				processData : false,
				success: function(data, textStatus) {
//					alert(data);
					$('body').prepend('<div id="overlayer"> </div>');
					$('#overlayer').append('<form action="' + window.location.href +'" method="post" class="foverlayer" >' + data + '</form>');
				}			
			});
			e.preventDefault ? e.preventDefault() : e.returnValue = false;
			
		});
		
    };
 
    Plugin.prototype.fooBar = function(someValue) {
        var fooBarModifier = 3;
 
        function privateFooBar(someValue) {
            return someValue * fooBarModifier;
        }
 
        someValue = privateFooBar(someValue);
        return someValue;
    };
 
    $.fn[pluginName] = function ( options ) {
        return this.each(function () {
            if (!$.data(this, 'plugin_' + pluginName)) {
                $.data(this, 'plugin_' + pluginName, 
                new Plugin( this, options ));
            }
        });
    }
})( jQuery, window, document );

/**
 * Plugin Hauptnavigation mit jQuery
 * Guppen 2. und 3. Ebene werden �ber javascript aufgef�llt 
 */

;(function ( $, window, document, undefined ) {
    "use strict";
 
    var pluginName = 'extendMainNavi',
        defaults = {
            animatespeed: 300,
			delaytime	: 200,
			allreadyajaxing	: false,
			language	: $('meta[name=language]').attr("content")			
        };    
 
    function Plugin( element, options ) {
 
        this.element = element;
        this.options = $.extend( {}, defaults, options) ;
 
        this._defaults = defaults;
        this._name = pluginName;
 
        this.init();
 
    }
 
    Plugin.prototype.init = function () {
		setEvent(this.element, this.options);
    };
	
	var setEvent = function (element, options) {
//		alert($(element).attr('name'));
		var loadingtimer;
		var date       = new Date();
		var datestamp  = ('0'+date.getFullYear()).substr(-2,2)+('1'+date.getMonth()).substr(-2,2)+('0'+date.getDate()).substr(-2,2);
		/* Menues erweitern erst bei Moseover*/
			$(element).bind('mouseenter',(function(){
				element.mousein = true;
				
				var clicked = false;
				$(element).click(function(){clicked = true;});
				// rootchild id
				var id = $(element).attr('name');
				// get stored data
				var $storedData = localStorage.getItem('group_' + id + '_' + options.language );
				var $storedDate = localStorage.getItem('group_' + id + '_' + options.language + '_date');
				$(element).on('bescheid', function(){animateMenueholder(element, element, options);});      			
				$("#" + id).parent().attr("id", "menueholder");
				$("#" + id).parent().attr("class", "greenBorder");
				// data saved and up to date?
                // F�r die Neue Suche und der Gruppen�bersicht mal die Abfrage 
				if (($storedData === null || parseInt($storedDate) < datestamp || $('.newVersion').length > 0) && !clicked && !options.allreadyajaxing) {
					options.allreadyajaxing = true;
					// loadingdiv
					loadingtimer = setTimeout(function(){$(element).append('<div class="loading_div greenBorder" style="left:0;"> </div>');}, options.delaytime);
					$(element).bind('mouseleave', function(){
								 element.mousein = false;
								 clearTimeout(loadingtimer);
								 $(".loading_div", element).remove();

							});
					
					$.ajax({
						url: "?ACTION=514&ID=10&GROUP=" + id,
						contentType : "application/json; charset=ISO-8859-1",
						dataType    : "json",
						cache       : false,
						async       : true,
						processData : false,
						success: 
								function(data, textStatus) {
										options.allreadyajaxing = false;
										localStorage.setItem('group_' + id + '_' + data[2].lang[0].lang, JSON.stringify(data));
										localStorage.setItem('group_' + id + '_' + data[2].lang[0].lang + '_date', datestamp);
										fillMenueholder(data, element, options);
								}			
								});
				} else {
					if(!options.allreadyajaxing) {
						fillMenueholder(JSON.parse($storedData), element, options);
					}
				}
			}))	;
		
	};
	
	/*
	* Function animateMenueholder
	* F�llt und f�gt den Menueholder an.
	* 
	* @param rootgroup - parent
	* @param callback  - optional
	*/
	var animateMenueholder = function(rootgroup, element, options) {
	   var timer;
	   // this Verluste minimieren
	   var $mholder = $("#menueholder", element);
	   //Wenn alles voll : einfaden
	   timer = setTimeout(function(){
								if(element.mousein){
									$mholder.fadeIn(options.animatespeed);
								}
							  }, options.delaytime);

	   // Mouseover entfernen und Hover setzen
	   $(rootgroup)    .unbind('mouseenter mouseleave')
	   
					   .click(function(){clearTimeout(timer);})
					   .hover(
							   function(){
								   clearTimeout(timer);
								   timer = setTimeout(function(){$mholder.fadeIn(options.animatespeed);}, options.delaytime);
							   },
							   function(){
								   clearTimeout(timer);
								   timer = setTimeout(function(){$mholder.fadeOut(options.animatespeed);}, options.delaytime);
							  });
	   // Loadingdiv l�schen
	   setTimeout(function(){$(".loading_div", element).remove();}, 200);
	   // Aufklappen der der Unterpunkte
	   $('.moreInfo', rootgroup).click(function(e){
		   $(this).hide();
		   $('.hiddenGroups', $(this).parent().parent()).slideDown(options.animatespeed);
		   e.preventDefault ? e.preventDefault() : e.returnValue = false;
	   });
	};
	
	var fillMenueholder = function(jsondata, element, options) {
		var id = $(element).attr('name');
		// Maximale Anzahl Untergruppen 
		var columsettings = {
			elementspercolumn   : 1,    // Preset, calculating later
			maxchildrow         : 20,   // Max shown Rootchildchilds :)
			maxcolums           : 5,    // Max colums :)
			magicmultiplier     : 0.85  // multiplier for homogenous display
		};
		// for large rootchilds
		if(jsondata[1].rowcount > 80) {
			// columsettings['maxchildrow'] = columsettings['maxcolums'];
		}
		

		var $counter    = 1;
//				alert( $rootchild + "  " + $elementspercolumn)
		var column = 1;
		/* rootdhild leeren und umbenennen um es mit Javascript neu zu f�llen */
		$("#" + id).empty()
					.attr("id", id + "_column_" + column)
					.removeClass("rootchilds")
					.addClass("js_rootchilds");
		var x = 0;
        var arr=["8241","8242","8243","8244"];
		// Count the important Elements
		$.each(jsondata[0].rootchilds, function(i, item) {
			// rootchilds mrauchen mehr Platz
			x += 2;
            if(jQuery.inArray(item.refid,arr) > 0 ){ // Special f�r Raspberry
    			x += 6;
                columsettings['maxchildrow']=100;
            }
			if(item.groups){
				$.each(item.groups, function(j, subitem){
					if(j < columsettings['maxchildrow']){
						x++;
					}
				});
			}
		});

		columsettings['elementspercolumn'] = Math.ceil(x / columsettings['maxcolums']);

			// Rootchilds f�llen
		$.each(jsondata[0].rootchilds, function(i, item) {
			// Magic multiplier to create the optimal columnheight
//                var $childs             = 0;
			if (jsondata[1].rowcount > 160) {
			   columsettings['magicmultiplier'] = 0.9;
			}
//                if(item.groups){
//                    $childs = item.groups.length;
//                }
			// New Column?
			if ($counter > (columsettings['elementspercolumn'] * columsettings['magicmultiplier']) && column < columsettings['maxcolums']){
					column++;
					$counter = 1;
					var $newcolumn = "<ul class='js_rootchilds' id='" + id + "_column_" + column +"'> </ul>";
					$($newcolumn).appendTo($("#" + id + "_column_" + (column-1)).parent());
//			$("<li id='child_" + item.refid + "_column_" +  $column + "'></li>").appendTo("#" + id + "_column_" + $column);
					$("<ul id='" + item.refid +	"_column_" +  column + "'> </ul>").appendTo("#child_" + item.refid + "_column_" + column);
			}
			var $a_data = "<li id='child_" + item.refid + "_column_" +  column + "'><a href='" + item.link + "' class='rootchild'>" + item.label +"</a></li>";
			$($a_data).appendTo("#" + id + "_column_" + column);
			$("<ul id='" + item.refid +	"_column_" +  column + "'> </ul>").appendTo("#child_" + item.refid + "_column_" + column);
			$counter+=2;
			if(item.groups){
				var grouplenght = $(item.groups).length;
				// Gruppen zu lang und k�rzen?
				var cutgroups = false;
				if ((grouplenght -1 > columsettings['maxchildrow'])) {
					cutgroups = true;
				}
//				alert(grouplenght);
				$.each(item.groups, function(i, subitem){
					// max $maxrow Childs
					if (i < columsettings['maxchildrow'] || !cutgroups ){
						var $b_data = "<li><a href='" + subitem.link + "' id='" + subitem.refid +"'>" + subitem.label +"</a></li>";
						$($b_data).appendTo("#" + item.refid + "_column_" +  column);
						$counter++;
						if (i === columsettings['maxchildrow'] -1 &&  cutgroups) {
							var $b_data = "<li><a class='moreInfo' href='" + item.link + "'>" + jsondata[2].lang[0].more +"</a></li>";
							$($b_data).appendTo("#" + item.refid + "_column_" +  column);
						}
//                            // Umbrechen in Untergruppen unsch�n
//                            if ($counter > columsettings['elementspercolumn']){
//                                column++;
//                                $counter = 1;
//                                $newcolumn = "<ul class='js_rootchilds' id='" + id + "_column_" + column +"'> </ul>";
//                                $($newcolumn).appendTo($("#" + id + "_column_" + (column-1)).parent());
//                                $("<li id='child_" + item.refid + "_column_" +  column + "'></li>").appendTo("#" + id + "_column_" + column);
//                                $("<ul id='" + item.refid +	"_column_" +  column + "'> </ul>").appendTo("#child_" + item.refid + "_column_" + column);
//                            }
					} else {
						// alles hinter mehr verstecken
						var $b_data = "<li><a class='hiddenGroups' href='" + subitem.link + "' id='" + subitem.refid +"'>" + subitem.label +"</a></li>";
						$($b_data).appendTo("#" + item.refid + "_column_" +  column);
//						if (!cutgroups) {
//							$counter++;
//						}
					}
				});
			} else {
				var $space_data = "<li class='space'> </li>";
				$($space_data).appendTo("#" + id + "_column_" + column);
			}
		});
		$(element).trigger('bescheid');
		
	};
 
    $.fn[pluginName] = function ( options ) {
        return this.each(function () {
            if (!$.data(this, 'plugin_' + pluginName)) {
                $.data(this, 'plugin_' + pluginName, 
                new Plugin( this, options ));
            }
        });
    }
})( jQuery, window, document );
//Magnific Popup
// Magnific Popup v0.9.8 by Dmitry Semenov
// http://bit.ly/magnific-popup#build=inline+image+ajax+iframe+gallery+fastclick
(function (a) {
    var b = "Close",
        c = "BeforeClose",
        d = "AfterClose",
        e = "BeforeAppend",
        f = "MarkupParse",
        g = "Open",
        h = "Change",
        i = "mfp",
        j = "." + i,
        k = "mfp-ready",
        l = "mfp-removing",
        m = "mfp-prevent-close",
        n, o = function () {}, p = !! window.jQuery,
        q, r = a(window),
        s, t, u, v, w, x = function (a, b) {
            n.ev.on(i + a + j, b)
        }, y = function (b, c, d, e) {
            var f = document.createElement("div");
            return f.className = "mfp-" + b, d && (f.innerHTML = d), e ? c && c.appendChild(f) : (f = a(f), c && f.appendTo(c)), f
        }, z = function (b, c) {
            n.ev.triggerHandler(i + b, c), n.st.callbacks && (b = b.charAt(0).toLowerCase() + b.slice(1), n.st.callbacks[b] && n.st.callbacks[b].apply(n, a.isArray(c) ? c : [c]))
        }, A = function () {
            (n.st.focus ? n.content.find(n.st.focus).eq(0) : n.wrap).focus()
        }, B = function (b) {
            if (b !== w || !n.currTemplate.closeBtn) n.currTemplate.closeBtn = a(n.st.closeMarkup.replace("%title%", n.st.tClose)), w = b;
            return n.currTemplate.closeBtn
        }, C = function () {
            a.magnificPopup.instance || (n = new o, n.init(), a.magnificPopup.instance = n)
        }, D = function () {
            var a = document.createElement("p").style,
                b = ["ms", "O", "Moz", "Webkit"];
            if (a.transition !== undefined) return !0;
            while (b.length)
                if (b.pop() + "Transition" in a) return !0;
            return !1
        };
    o.prototype = {
        constructor: o,
        init: function () {
            var b = navigator.appVersion;
            n.isIE7 = b.indexOf("MSIE 7.") !== -1, n.isIE8 = b.indexOf("MSIE 8.") !== -1, n.isLowIE = n.isIE7 || n.isIE8, n.isAndroid = /android/gi.test(b), n.isIOS = /iphone|ipad|ipod/gi.test(b), n.supportsTransition = D(), n.probablyMobile = n.isAndroid || n.isIOS || /(Opera Mini)|Kindle|webOS|BlackBerry|(Opera Mobi)|(Windows Phone)|IEMobile/i.test(navigator.userAgent), s = a(document.body), t = a(document), n.popupsCache = {}
        },
        open: function (b) {
            var c;
            if (b.isObj === !1) {
                n.items = b.items.toArray(), n.index = 0;
                var d = b.items,
                    e;
                for (c = 0; c < d.length; c++) {
                    e = d[c], e.parsed && (e = e.el[0]);
                    if (e === b.el[0]) {
                        n.index = c;
                        break
                    }
                }
            } else n.items = a.isArray(b.items) ? b.items : [b.items], n.index = b.index || 0; if (n.isOpen) {
                n.updateItemHTML();
                return
            }
            n.types = [], v = "", b.mainEl && b.mainEl.length ? n.ev = b.mainEl.eq(0) : n.ev = t, b.key ? (n.popupsCache[b.key] || (n.popupsCache[b.key] = {}), n.currTemplate = n.popupsCache[b.key]) : n.currTemplate = {}, n.st = a.extend(!0, {}, a.magnificPopup.defaults, b), n.fixedContentPos = n.st.fixedContentPos === "auto" ? !n.probablyMobile : n.st.fixedContentPos, n.st.modal && (n.st.closeOnContentClick = !1, n.st.closeOnBgClick = !1, n.st.showCloseBtn = !1, n.st.enableEscapeKey = !1), n.bgOverlay || (n.bgOverlay = y("bg").on("click" + j, function () {
                n.close()
            }), n.wrap = y("wrap").attr("tabindex", -1).on("click" + j, function (a) {
                n._checkIfClose(a.target) && n.close()
            }), n.container = y("container", n.wrap)), n.contentContainer = y("content"), n.st.preloader && (n.preloader = y("preloader", n.container, n.st.tLoading));
            var h = a.magnificPopup.modules;
            for (c = 0; c < h.length; c++) {
                var i = h[c];
                i = i.charAt(0).toUpperCase() + i.slice(1), n["init" + i].call(n)
            }
            z("BeforeOpen"), n.st.showCloseBtn && (n.st.closeBtnInside ? (x(f, function (a, b, c, d) {
                c.close_replaceWith = B(d.type)
            }), v += " mfp-close-btn-in") : n.wrap.append(B())), n.st.alignTop && (v += " mfp-align-top"), n.fixedContentPos ? n.wrap.css({
                overflow: n.st.overflowY,
                overflowX: "hidden",
                overflowY: n.st.overflowY
            }) : n.wrap.css({
                top: r.scrollTop(),
                position: "absolute"
            }), (n.st.fixedBgPos === !1 || n.st.fixedBgPos === "auto" && !n.fixedContentPos) && n.bgOverlay.css({
                height: t.height(),
                position: "absolute"
            }), n.st.enableEscapeKey && t.on("keyup" + j, function (a) {
                a.keyCode === 27 && n.close()
            }), r.on("resize" + j, function () {
                n.updateSize()
            }), n.st.closeOnContentClick || (v += " mfp-auto-cursor"), v && n.wrap.addClass(v);
            var l = n.wH = r.height(),
                m = {};
            if (n.fixedContentPos && n._hasScrollBar(l)) {
                var o = n._getScrollbarSize();
                o && (m.marginRight = o)
            }
            n.fixedContentPos && (n.isIE7 ? a("body, html").css("overflow", "hidden") : m.overflow = "hidden");
            var p = n.st.mainClass;
            return n.isIE7 && (p += " mfp-ie7"), p && n._addClassToMFP(p), n.updateItemHTML(), z("BuildControls"), a("html").css(m), n.bgOverlay.add(n.wrap).prependTo(document.body), n._lastFocusedEl = document.activeElement, setTimeout(function () {
                n.content ? (n._addClassToMFP(k), A()) : n.bgOverlay.addClass(k), t.on("focusin" + j, function (b) {
                    if (b.target !== n.wrap[0] && !a.contains(n.wrap[0], b.target)) return A(), !1
                })
            }, 16), n.isOpen = !0, n.updateSize(l), z(g), b
        },
        close: function () {
            if (!n.isOpen) return;
            z(c), n.isOpen = !1, n.st.removalDelay && !n.isLowIE && n.supportsTransition ? (n._addClassToMFP(l), setTimeout(function () {
                n._close()
            }, n.st.removalDelay)) : n._close()
        },
        _close: function () {
            z(b);
            var c = l + " " + k + " ";
            n.bgOverlay.detach(), n.wrap.detach(), n.container.empty(), n.st.mainClass && (c += n.st.mainClass + " "), n._removeClassFromMFP(c);
            if (n.fixedContentPos) {
                var e = {
                    marginRight: ""
                };
                n.isIE7 ? a("body, html").css("overflow", "") : e.overflow = "", a("html").css(e)
            }
            t.off("keyup" + j + " focusin" + j), n.ev.off(j), n.wrap.attr("class", "mfp-wrap").removeAttr("style"), n.bgOverlay.attr("class", "mfp-bg"), n.container.attr("class", "mfp-container"), n.st.showCloseBtn && (!n.st.closeBtnInside || n.currTemplate[n.currItem.type] === !0) && n.currTemplate.closeBtn && n.currTemplate.closeBtn.detach(), n._lastFocusedEl && a(n._lastFocusedEl).focus(), n.currItem = null, n.content = null, n.currTemplate = null, n.prevHeight = 0, z(d)
        },
        updateSize: function (a) {
            if (n.isIOS) {
                var b = document.documentElement.clientWidth / window.innerWidth,
                    c = window.innerHeight * b;
                n.wrap.css("height", c), n.wH = c
            } else n.wH = a || r.height();
            n.fixedContentPos || n.wrap.css("height", n.wH), z("Resize")
        },
        updateItemHTML: function () {
            var b = n.items[n.index];
            n.contentContainer.detach(), n.content && n.content.detach(), b.parsed || (b = n.parseEl(n.index));
            var c = b.type;
            z("BeforeChange", [n.currItem ? n.currItem.type : "", c]), n.currItem = b;
            if (!n.currTemplate[c]) {
                var d = n.st[c] ? n.st[c].markup : !1;
                z("FirstMarkupParse", d), d ? n.currTemplate[c] = a(d) : n.currTemplate[c] = !0
            }
            u && u !== b.type && n.container.removeClass("mfp-" + u + "-holder");
            var e = n["get" + c.charAt(0).toUpperCase() + c.slice(1)](b, n.currTemplate[c]);
            n.appendContent(e, c), b.preloaded = !0, z(h, b), u = b.type, n.container.prepend(n.contentContainer), z("AfterChange")
        },
        appendContent: function (a, b) {
            n.content = a, a ? n.st.showCloseBtn && n.st.closeBtnInside && n.currTemplate[b] === !0 ? n.content.find(".mfp-close").length || n.content.append(B()) : n.content = a : n.content = "", z(e), n.container.addClass("mfp-" + b + "-holder"), n.contentContainer.append(n.content)
        },
        parseEl: function (b) {
            var c = n.items[b],
                d = c.type;
            c.tagName ? c = {
                el: a(c)
            } : c = {
                data: c,
                src: c.src
            };
            if (c.el) {
                var e = n.types;
                for (var f = 0; f < e.length; f++)
                    if (c.el.hasClass("mfp-" + e[f])) {
                        d = e[f];
                        break
                    }
                c.src = c.el.attr("data-mfp-src"), c.src || (c.src = c.el.attr("href"))
            }
            return c.type = d || n.st.type || "inline", c.index = b, c.parsed = !0, n.items[b] = c, z("ElementParse", c), n.items[b]
        },
        addGroup: function (a, b) {
            var c = function (c) {
                c.mfpEl = this, n._openClick(c, a, b)
            };
            b || (b = {});
            var d = "click.magnificPopup";
            b.mainEl = a, b.items ? (b.isObj = !0, a.off(d).on(d, c)) : (b.isObj = !1, b.delegate ? a.off(d).on(d, b.delegate, c) : (b.items = a, a.off(d).on(d, c)))
        },
        _openClick: function (b, c, d) {
            var e = d.midClick !== undefined ? d.midClick : a.magnificPopup.defaults.midClick;
            if (!e && (b.which === 2 || b.ctrlKey || b.metaKey)) return;
            var f = d.disableOn !== undefined ? d.disableOn : a.magnificPopup.defaults.disableOn;
            if (f)
                if (a.isFunction(f)) {
                    if (!f.call(n)) return !0
                } else if (r.width() < f) return !0;
            b.type && (b.preventDefault(), n.isOpen && b.stopPropagation()), d.el = a(b.mfpEl), d.delegate && (d.items = c.find(d.delegate)), n.open(d)
        },
        updateStatus: function (a, b) {
            if (n.preloader) {
                q !== a && n.container.removeClass("mfp-s-" + q), !b && a === "loading" && (b = n.st.tLoading);
                var c = {
                    status: a,
                    text: b
                };
                z("UpdateStatus", c), a = c.status, b = c.text, n.preloader.html(b), n.preloader.find("a").on("click", function (a) {
                    a.stopImmediatePropagation()
                }), n.container.addClass("mfp-s-" + a), q = a
            }
        },
        _checkIfClose: function (b) {
            if (a(b).hasClass(m)) return;
            var c = n.st.closeOnContentClick,
                d = n.st.closeOnBgClick;
            if (c && d) return !0;
            if (!n.content || a(b).hasClass("mfp-close") || n.preloader && b === n.preloader[0]) return !0;
            if (b !== n.content[0] && !a.contains(n.content[0], b)) {
                if (d && a.contains(document, b)) return !0
            } else if (c) return !0;
            return !1
        },
        _addClassToMFP: function (a) {
            n.bgOverlay.addClass(a), n.wrap.addClass(a)
        },
        _removeClassFromMFP: function (a) {
            this.bgOverlay.removeClass(a), n.wrap.removeClass(a)
        },
        _hasScrollBar: function (a) {
            return (n.isIE7 ? t.height() : document.body.scrollHeight) > (a || r.height())
        },
        _parseMarkup: function (b, c, d) {
            var e;
            d.data && (c = a.extend(d.data, c)), z(f, [b, c, d]), a.each(c, function (a, c) {
                if (c === undefined || c === !1) return !0;
                e = a.split("_");
                if (e.length > 1) {
                    var d = b.find(j + "-" + e[0]);
                    if (d.length > 0) {
                        var f = e[1];
                        f === "replaceWith" ? d[0] !== c[0] && d.replaceWith(c) : f === "img" ? d.is("img") ? d.attr("src", c) : d.replaceWith('<img src="' + c + '" class="' + d.attr("class") + '" />') : d.attr(e[1], c)
                    }
                } else b.find(j + "-" + a).html(c)
            })
        },
        _getScrollbarSize: function () {
            if (n.scrollbarSize === undefined) {
                var a = document.createElement("div");
                a.id = "mfp-sbm", a.style.cssText = "width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;", document.body.appendChild(a), n.scrollbarSize = a.offsetWidth - a.clientWidth, document.body.removeChild(a)
            }
            return n.scrollbarSize
        }
    }, a.magnificPopup = {
        instance: null,
        proto: o.prototype,
        modules: [],
        open: function (b, c) {
            return C(), b ? b = a.extend(!0, {}, b) : b = {}, b.isObj = !0, b.index = c || 0, this.instance.open(b)
        },
        close: function () {
            return a.magnificPopup.instance && a.magnificPopup.instance.close()
        },
        registerModule: function (b, c) {
            c.options && (a.magnificPopup.defaults[b] = c.options), a.extend(this.proto, c.proto), this.modules.push(b)
        },
        defaults: {
            disableOn: 0,
            key: null,
            midClick: !1,
            mainClass: "",
            preloader: !0,
            focus: "",
            closeOnContentClick: !1,
            closeOnBgClick: !0,
            closeBtnInside: !0,
            showCloseBtn: !0,
            enableEscapeKey: !0,
            modal: !1,
            alignTop: !1,
            removalDelay: 0,
            fixedContentPos: "auto",
            fixedBgPos: "auto",
            overflowY: "auto",
            closeMarkup: '<button title="%title%" type="button" class="mfp-close">&times;</button>',
            tClose: "Close (Esc)",
            tLoading: "Loading..."
        }
    }, a.fn.magnificPopup = function (b) {
        C();
        var c = a(this);
        if (typeof b == "string")
            if (b === "open") {
                var d, e = p ? c.data("magnificPopup") : c[0].magnificPopup,
                    f = parseInt(arguments[1], 10) || 0;
                e.items ? d = e.items[f] : (d = c, e.delegate && (d = d.find(e.delegate)), d = d.eq(f)), n._openClick({
                    mfpEl: d
                }, c, e)
            } else n.isOpen && n[b].apply(n, Array.prototype.slice.call(arguments, 1));
            else b = a.extend(!0, {}, b), p ? c.data("magnificPopup", b) : c[0].magnificPopup = b, n.addGroup(c, b);
        return c
    };
    var E = "inline",
        F, G, H, I = function () {
            H && (G.after(H.addClass(F)).detach(), H = null)
        };
    a.magnificPopup.registerModule(E, {
        options: {
            hiddenClass: "hide",
            markup: "",
            tNotFound: "Content not found"
        },
        proto: {
            initInline: function () {
                n.types.push(E), x(b + "." + E, function () {
                    I()
                })
            },
            getInline: function (b, c) {
                I();
                if (b.src) {
                    var d = n.st.inline,
                        e = a(b.src);
                    if (e.length) {
                        var f = e[0].parentNode;
                        f && f.tagName && (G || (F = d.hiddenClass, G = y(F), F = "mfp-" + F), H = e.after(G).detach().removeClass(F)), n.updateStatus("ready")
                    } else n.updateStatus("error", d.tNotFound), e = a("<div>");
                    return b.inlineElement = e, e
                }
                return n.updateStatus("ready"), n._parseMarkup(c, {}, b), c
            }
        }
    });
    var J = "ajax",
        K, L = function () {
            K && s.removeClass(K)
        }, M = function () {
            L(), n.req && n.req.abort()
        };
    a.magnificPopup.registerModule(J, {
        options: {
            settings: null,
            cursor: "mfp-ajax-cur",
            tError: '<a href="%url%">The content</a> could not be loaded.'
        },
        proto: {
            initAjax: function () {
                n.types.push(J), K = n.st.ajax.cursor, x(b + "." + J, M), x("BeforeChange." + J, M)
            },
            getAjax: function (b) {
                K && s.addClass(K), n.updateStatus("loading");
                var c = a.extend({
                    url: b.src,
                    success: function (c, d, e) {
                        var f = {
                            data: c,
                            xhr: e
                        };
                        z("ParseAjax", f), n.appendContent(a(f.data), J), b.finished = !0, L(), A(), setTimeout(function () {
                            n.wrap.addClass(k)
                        }, 16), n.updateStatus("ready"), z("AjaxContentAdded")
                    },
                    error: function () {
                        L(), b.finished = b.loadError = !0, n.updateStatus("error", n.st.ajax.tError.replace("%url%", b.src))
                    }
                }, n.st.ajax.settings);
                return n.req = a.ajax(c), ""
            }
        }
    });
    var N, O = function (b) {
            if (b.data && b.data.title !== undefined) return b.data.title;
            var c = n.st.image.titleSrc;
            if (c) {
                if (a.isFunction(c)) return c.call(n, b);
                if (b.el) return b.el.attr(c) || ""
            }
            return ""
        };
    a.magnificPopup.registerModule("image", {
        options: {
            markup: '<div class="mfp-figure"><div class="mfp-counter"></div><div class="mfp-close"></div><figure><div class="mfp-img"></div><figcaption><div class="mfp-bottom-bar"><div class="mfp-title"></div></div></figcaption></figure></div>',
            cursor: "mfp-zoom-out-cur",
            titleSrc: "title",
            verticalFit: !0,
            tError: '<a href="%url%">The image</a> could not be loaded.'
        },
        proto: {
            initImage: function () {
                var a = n.st.image,
                    c = ".image";
                n.types.push("image"), x(g + c, function () {
                    n.currItem.type === "image" && a.cursor && s.addClass(a.cursor)
                }), x(b + c, function () {
                    a.cursor && s.removeClass(a.cursor), r.off("resize" + j)
                }), x("Resize" + c, n.resizeImage), n.isLowIE && x("AfterChange", n.resizeImage)
            },
            resizeImage: function () {
                var a = n.currItem;
                if (!a || !a.img) return;
                if (n.st.image.verticalFit) {
                    var b = 0;
                    n.isLowIE && (b = parseInt(a.img.css("padding-top"), 10) + parseInt(a.img.css("padding-bottom"), 10)), a.img.css("max-height", n.wH - b)
                }
            },
            _onImageHasSize: function (a) {
                a.img && (a.hasSize = !0, N && clearInterval(N), a.isCheckingImgSize = !1, z("ImageHasSize", a), a.imgHidden && (n.content && n.content.removeClass("mfp-loading"), a.imgHidden = !1))
            },
            findImageSize: function (a) {
                var b = 0,
                    c = a.img[0],
                    d = function (e) {
                        N && clearInterval(N), N = setInterval(function () {
                            if (c.naturalWidth > 0) {
                                n._onImageHasSize(a);
                                return
                            }
                            b > 200 && clearInterval(N), b++, b === 3 ? d(10) : b === 40 ? d(50) : b === 100 && d(500)
                        }, e)
                    };
                d(1)
            },
            getImage: function (b, c) {
                var d = 0,
                    e = function () {
                        b && (b.img[0].complete ? (b.img.off(".mfploader"), b === n.currItem && (n._onImageHasSize(b), n.updateStatus("ready")), b.hasSize = !0, b.loaded = !0, z("ImageLoadComplete")) : (d++, d < 200 ? setTimeout(e, 100) : f()))
                    }, f = function () {
                        b && (b.img.off(".mfploader"), b === n.currItem && (n._onImageHasSize(b), n.updateStatus("error", g.tError.replace("%url%", b.src))), b.hasSize = !0, b.loaded = !0, b.loadError = !0)
                    }, g = n.st.image,
                    h = c.find(".mfp-img");
                if (h.length) {
                    var i = document.createElement("img");
                    i.className = "mfp-img", b.img = a(i).on("load.mfploader", e).on("error.mfploader", f), i.src = b.src, h.is("img") && (b.img = b.img.clone()), b.img[0].naturalWidth > 0 && (b.hasSize = !0)
                }
                return n._parseMarkup(c, {
                    title: O(b),
                    img_replaceWith: b.img
                }, b), n.resizeImage(), b.hasSize ? (N && clearInterval(N), b.loadError ? (c.addClass("mfp-loading"), n.updateStatus("error", g.tError.replace("%url%", b.src))) : (c.removeClass("mfp-loading"), n.updateStatus("ready")), c) : (n.updateStatus("loading"), b.loading = !0, b.hasSize || (b.imgHidden = !0, c.addClass("mfp-loading"), n.findImageSize(b)), c)
            }
        }
    });
    var P, Q = function () {
            return P === undefined && (P = document.createElement("p").style.MozTransform !== undefined), P
        };
    a.magnificPopup.registerModule("zoom", {
        options: {
            enabled: !1,
            easing: "ease-in-out",
            duration: 300,
            opener: function (a) {
                return a.is("img") ? a : a.find("img")
            }
        },
        proto: {
            initZoom: function () {
                var a = n.st.zoom,
                    d = ".zoom",
                    e;
                if (!a.enabled || !n.supportsTransition) return;
                var f = a.duration,
                    g = function (b) {
                        var c = b.clone().removeAttr("style").removeAttr("class").addClass("mfp-animated-image"),
                            d = "all " + a.duration / 1e3 + "s " + a.easing,
                            e = {
                                position: "fixed",
                                zIndex: 9999,
                                left: 0,
                                top: 0,
                                "-webkit-backface-visibility": "hidden"
                            }, f = "transition";
                        return e["-webkit-" + f] = e["-moz-" + f] = e["-o-" + f] = e[f] = d, c.css(e), c
                    }, h = function () {
                        n.content.css("visibility", "visible")
                    }, i, j;
                x("BuildControls" + d, function () {
                    if (n._allowZoom()) {
                        clearTimeout(i), n.content.css("visibility", "hidden"), e = n._getItemToZoom();
                        if (!e) {
                            h();
                            return
                        }
                        j = g(e), j.css(n._getOffset()), n.wrap.append(j), i = setTimeout(function () {
                            j.css(n._getOffset(!0)), i = setTimeout(function () {
                                h(), setTimeout(function () {
                                    j.remove(), e = j = null, z("ZoomAnimationEnded")
                                }, 16)
                            }, f)
                        }, 16)
                    }
                }), x(c + d, function () {
                    if (n._allowZoom()) {
                        clearTimeout(i), n.st.removalDelay = f;
                        if (!e) {
                            e = n._getItemToZoom();
                            if (!e) return;
                            j = g(e)
                        }
                        j.css(n._getOffset(!0)), n.wrap.append(j), n.content.css("visibility", "hidden"), setTimeout(function () {
                            j.css(n._getOffset())
                        }, 16)
                    }
                }), x(b + d, function () {
                    n._allowZoom() && (h(), j && j.remove(), e = null)
                })
            },
            _allowZoom: function () {
                return n.currItem.type === "image"
            },
            _getItemToZoom: function () {
                return n.currItem.hasSize ? n.currItem.img : !1
            },
            _getOffset: function (b) {
                var c;
                b ? c = n.currItem.img : c = n.st.zoom.opener(n.currItem.el || n.currItem);
                var d = c.offset(),
                    e = parseInt(c.css("padding-top"), 10),
                    f = parseInt(c.css("padding-bottom"), 10);
                d.top -= a(window).scrollTop() - e;
                var g = {
                    width: c.width(),
                    height: (p ? c.innerHeight() : c[0].offsetHeight) - f - e
                };
                return Q() ? g["-moz-transform"] = g.transform = "translate(" + d.left + "px," + d.top + "px)" : (g.left = d.left, g.top = d.top), g
            }
        }
    });
    var R = "iframe",
        S = "//about:blank",
        T = function (a) {
            if (n.currTemplate[R]) {
                var b = n.currTemplate[R].find("iframe");
                b.length && (a || (b[0].src = S), n.isIE8 && b.css("display", a ? "block" : "none"))
            }
        };
    a.magnificPopup.registerModule(R, {
        options: {
            markup: '<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe></div>',
            srcAction: "iframe_src",
            patterns: {
                youtube: {
                    index: "youtube.com",
                    id: "v=",
                    src: "//www.youtube.com/embed/%id%?autoplay=1"
                },
                vimeo: {
                    index: "vimeo.com/",
                    id: "/",
                    src: "//player.vimeo.com/video/%id%?autoplay=1"
                },
                gmaps: {
                    index: "//maps.google.",
                    src: "%id%&output=embed"
                }

            }
        },
        proto: {
            initIframe: function () {
                n.types.push(R), x("BeforeChange", function (a, b, c) {
                    b !== c && (b === R ? T() : c === R && T(!0))
                }), x(b + "." + R, function () {
                    T()
                })
            },
            getIframe: function (b, c) {
                var d = b.src,
                    e = n.st.iframe;
                a.each(e.patterns, function () {
                    if (d.indexOf(this.index) > -1) return this.id && (typeof this.id == "string" ? d = d.substr(d.lastIndexOf(this.id) + this.id.length, d.length) : d = this.id.call(this, d)), d = this.src.replace("%id%", d), !1
                });
                var f = {};
                return e.srcAction && (f[e.srcAction] = d), n._parseMarkup(c, f, b), n.updateStatus("ready"), c
            }
        }
    });
    var U = function (a) {
        var b = n.items.length;
        return a > b - 1 ? a - b : a < 0 ? b + a : a
    }, V = function (a, b, c) {
            return a.replace(/%curr%/gi, b + 1).replace(/%total%/gi, c)
        };
    a.magnificPopup.registerModule("gallery", {
        options: {
            enabled: !1,
            arrowMarkup: '<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"></button>',
            preload: [0, 2],
            navigateByImgClick: !0,
            arrows: !0,
            tPrev: "Previous (Left arrow key)",
            tNext: "Next (Right arrow key)",
            tCounter: "%curr% of %total%"
        },
        proto: {
            initGallery: function () {
                var c = n.st.gallery,
                    d = ".mfp-gallery",
                    e = Boolean(a.fn.mfpFastClick);
                n.direction = !0;
                if (!c || !c.enabled) return !1;
                v += " mfp-gallery", x(g + d, function () {
                    c.navigateByImgClick && n.wrap.on("click" + d, ".mfp-img", function () {
                        if (n.items.length > 1) return n.next(), !1
                    }), t.on("keydown" + d, function (a) {
                        a.keyCode === 37 ? n.prev() : a.keyCode === 39 && n.next()
                    })
                }), x("UpdateStatus" + d, function (a, b) {
                    b.text && (b.text = V(b.text, n.currItem.index, n.items.length))
                }), x(f + d, function (a, b, d, e) {
                    var f = n.items.length;
                    d.counter = f > 1 ? V(c.tCounter, e.index, f) : ""
                }), x("BuildControls" + d, function () {
                    if (n.items.length > 1 && c.arrows && !n.arrowLeft) {
                        var b = c.arrowMarkup,
                            d = n.arrowLeft = a(b.replace(/%title%/gi, c.tPrev).replace(/%dir%/gi, "left")).addClass(m),
                            f = n.arrowRight = a(b.replace(/%title%/gi, c.tNext).replace(/%dir%/gi, "right")).addClass(m),
                            g = e ? "mfpFastClick" : "click";
                        d[g](function () {
                            n.prev()
                        }), f[g](function () {
                            n.next()
                        }), n.isIE7 && (y("b", d[0], !1, !0), y("a", d[0], !1, !0), y("b", f[0], !1, !0), y("a", f[0], !1, !0)), n.container.append(d.add(f))
                    }
                }), x(h + d, function () {
                    n._preloadTimeout && clearTimeout(n._preloadTimeout), n._preloadTimeout = setTimeout(function () {
                        n.preloadNearbyImages(), n._preloadTimeout = null
                    }, 16)
                }), x(b + d, function () {
                    t.off(d), n.wrap.off("click" + d), n.arrowLeft && e && n.arrowLeft.add(n.arrowRight).destroyMfpFastClick(), n.arrowRight = n.arrowLeft = null
                })
            },
            next: function () {
                n.direction = !0, n.index = U(n.index + 1), n.updateItemHTML()
            },
            prev: function () {
                n.direction = !1, n.index = U(n.index - 1), n.updateItemHTML()
            },
            goTo: function (a) {
                n.direction = a >= n.index, n.index = a, n.updateItemHTML()
            },
            preloadNearbyImages: function () {
                var a = n.st.gallery.preload,
                    b = Math.min(a[0], n.items.length),
                    c = Math.min(a[1], n.items.length),
                    d;
                for (d = 1; d <= (n.direction ? c : b); d++) n._preloadItem(n.index + d);
                for (d = 1; d <= (n.direction ? b : c); d++) n._preloadItem(n.index - d)
            },
            _preloadItem: function (b) {
                b = U(b);
                if (n.items[b].preloaded) return;
                var c = n.items[b];
                c.parsed || (c = n.parseEl(b)), z("LazyLoad", c), c.type === "image" && (c.img = a('<img class="mfp-img" />').on("load.mfploader", function () {
                    c.hasSize = !0
                }).on("error.mfploader", function () {
                    c.hasSize = !0, c.loadError = !0, z("LazyLoadError", c)
                }).attr("src", c.src)), c.preloaded = !0
            }
        }
    }),
    function () {
        var b = 1e3,
            c = "ontouchstart" in window,
            d = function () {
                r.off("touchmove" + f + " touchend" + f)
            }, e = "mfpFastClick",
            f = "." + e;
        a.fn.mfpFastClick = function (e) {
            return a(this).each(function () {
                var g = a(this),
                    h;
                if (c) {
                    var i, j, k, l, m, n;
                    g.on("touchstart" + f, function (a) {
                        l = !1, n = 1, m = a.originalEvent ? a.originalEvent.touches[0] : a.touches[0], j = m.clientX, k = m.clientY, r.on("touchmove" + f, function (a) {
                            m = a.originalEvent ? a.originalEvent.touches : a.touches, n = m.length, m = m[0];
                            if (Math.abs(m.clientX - j) > 10 || Math.abs(m.clientY - k) > 10) l = !0, d()
                        }).on("touchend" + f, function (a) {
                            d();
                            if (l || n > 1) return;
                            h = !0, a.preventDefault(), clearTimeout(i), i = setTimeout(function () {
                                h = !1
                            }, b), e()
                        })
                    })
                }
                g.on("click" + f, function () {
                    h || e()
                })
            })
        }, a.fn.destroyMfpFastClick = function () {
            a(this).off("touchstart" + f + " click" + f), c && r.off("touchmove" + f + " touchend" + f)
        }
    }()
})(window.jQuery || window.Zepto);

function escapeRegExp (string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // $& meint den komplett erkannten String
}

(function($) {
    $(document).ready(function(){
		/**
		 * Returns URL-Parameter
		 * Usage:
		 * $.getUrlVars() -> all vars
		 * $.getUrlVar('name'); -> by name
		 * 
		 * @param {type} $
		 * @returns - URL-Param
		 */
		$.extend({
			getUrlVars: function(){
			  var vars = [], hash;
			  var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split(/[&;]+/);
			  for(var i = 0; i < hashes.length; i++)
			  {
				hash = hashes[i].split('=');
				vars.push(hash[0]);
				vars[hash[0]] = hash[1];
			  }
			  return vars;
			},
			getUrlVar: function(name){
			  return $.getUrlVars()[name];
			}
		  });
          
          
            $.extend($.expr[":"], {
                "containsNC": function(elem, i, match, array) {
                      return (elem.textContent || elem.innerText || "").toLowerCase().indexOf((match[3] || "").toLowerCase()) >= 0;
                            }
            });
          
        // Suchen in der Seite braucht nur ein Eingabefeld mit dem Namen 'PageSearch'
            var foundSearchVar = false;
            var starttag='<span class="searchtext">';
            var endtag  ='</span>';
            $("input[name='PageSearch']").bind({
                keyup: function(evt){
                    var searchVar = $(this).val();

                    if(foundSearchVar){
                        $(".searchtext").each(function(){
                            var oldsearch = $(this).html();
                            var innerhtml = $(this).parent().html();
                            if(innerhtml){
                                var sstring = starttag+oldsearch+endtag;
                                var re = new RegExp(escapeRegExp(sstring),"gi");
                                innerhtml = innerhtml.replace(re,oldsearch);
                                $(this).parent().html(innerhtml);
                            }
                        });
                        foundSearchVar = false;
                    }

                    if(searchVar.length > 2){
                        $('*:containsNC("'+searchVar+'")').each(function(){
                            if($(this).children().length < 1){
                                var html=$(this).html();
                                
                                var re2 = new RegExp("("+escapeRegExp(searchVar)+")","gi");
                                html=html.replace(re2,starttag+'$1'+endtag);
                                
                                $(this).html(html);
                                foundSearchVar = true;
                            }
                        });
                    }

                }
            })
        
        
          
          

        // Hack f�r Dynamisches Bildwechseln bei Themenseite
        $(".noprice").each(function() {
            var anchor = $( this ).parent().parent().parent().parent();
            var style= anchor.attr("style");
//            alert(style.replace(/\/([^\/]*)\.([jpgifnp]{3})/,"/off_\$1.\$2"));
            //anchor.attr("style",style.replace(/\.jpg/,"_off.jpg"));
            anchor.attr("style",style.replace(/\/([^\/]*)\.([jpgifnp]{3})/,"/off_\$1.\$2"));
//            anchor.attr("style",style.replace(/\/([^\/]*)\.png/,"/off_\$1.png"));
            $(this).parent().find("input").remove();
        });
        
        // Hack f�r checkboxen
        var defaults = {
            newElementClass: 'newcheckpic',
            activeElementClass: 'checkactive'
        }
 
        var options = $.extend(defaults, options);        
        
        $(".pluginfo").each(function() {
            $(this).bind('click', function(){
                $(".pluginfodiv",$(this).parent()).toggle();
                return(false);
            })
        });
       
        if (window.navigator.pointerEnabled) {
            $("#groupselector").hide();
        }
        
        var groupselectorclicked = false;
        
        $("select#groupselector").bind('click' , function() {
            if(!groupselectorclicked){
                $(this).addClass('over');
                $("#quicksearch_new").addClass('sqover');
            }else{
                groupselectorclicked = false;
//                $(this).removeClass('over');
//                $("#quicksearch_new").removeClass('sqover');
            }
        })
        
        $("select#groupselector").bind('mouseout' , function() {
            groupselectorclicked = false;
            $(this).removeClass('over');
            $("#quicksearch_new").removeClass('sqover');
        })
        
        $("select#groupselector").change(function() {
            $("select#groupselector").removeClass('over');
            $("#quicksearch_new").removeClass('sqover');
            groupselectorclicked = true;
        })
        
        
        $(".newcheck").each(function() {
            var obj = $(this);
            var newObj = $('<a/>', {
                'id'   : '#' + obj.attr('id'),
                'class': options.newElementClass,
                'style': 'display: block;'
            }).insertAfter(this);            
            
            //Make sure pre-checked boxes are rendered as checked
            if(obj.is(':checked')) {
                newObj.addClass(options.activeElementClass);
            }

            obj.hide(); //Hide original checkbox

            //Labels can be painful, let's fix that
            if($('[for=' + obj.attr('id') + ']').length) {

            var label = $('[for=' + obj.attr('id') + ']');
            
            label.click(function() {
                newObj.trigger('click'); //Force the label to fire our element
                return false;
            });

            }            
            newObj.click(function() {
                //Assign current clicked object
                var obj = $(this);
 
                //Check the current state of the checkbox
                if(obj.hasClass(options.activeElementClass)) {
                     obj.removeClass(options.activeElementClass);
                   $(obj.attr('id')).attr('checked',false);
                } else {
                     obj.addClass(options.activeElementClass);
                   $(obj.attr('id')).attr('checked',true);
                }
                
                //Kill the click function
                return false; 
                });            
        });
        
		// Umschalten auf Mobile + Cookie setzen
		$('#gotomobile').click(function(){
			setCookie('showmobile',true,30)
		});

		/*
		 * animate the Searchassis
		 */
		var animatespeed = 300; // milisec
		$('#searchassis').removeClass('noscript')
						.click(function(){
							if ($('#searchassis ul').is(':visible')) {
								$('#searchassis ul').fadeOut(animatespeed);
							} else {
								$('#searchassis ul').fadeIn(animatespeed);
							}
						})
						.hover(
			function(){
	//					$('#searchassis ul').fadeIn(animatespeed);
						},
			function(){$('#searchassis ul').fadeOut(animatespeed);}
			);

		/*
		 * animate the choosediv
		 */
		$('#statuslink, #myreicheltlink, #languageselect').removeClass('noscript')
	//					.click(function(){
	//						if ($('.choosediv', this).is(':visible')) {
	//							$('.choosediv', this).fadeOut(animatespeed);
	//						} else {
	//							$('.choosediv', this).fadeIn(animatespeed);
	//						}
	//					})
						.hover(
						function(){
                                    if ($(this).attr('id') != 'statuslink' && $(this).attr('id') != 'languageselect'){
                                        
                                        $('.choosediv', this).fadeIn(animatespeed);
                                        $('.chsdv', this).fadeIn(animatespeed);
                                        }
                                    },
						function(){
                            $('.choosediv', this).fadeOut(animatespeed);
                            $('.chsdv', this).fadeOut(animatespeed);
                        }
						)
                        .click(
                        function(){
                            if ($(this).attr('id') == 'statuslink' || $(this).attr('id') == 'languageselect'){
                                $('.choosediv', this).fadeIn(animatespeed);
                                $('.chsdv', this).fadeIn(animatespeed);
                                }
                            }
                        )
                ;

		$("#quicksearch")
//				.on('click', function () {$(this).select().unbind('click')}) // Doch doof
//				.focus()  // weiter oben, Probleme bei Touchger�ten
				.autocomplete({
	//		   appendTo: "#NewerSearch input", 
			   delay 	: 200,
			   minLength: 2,
			   source	: function (request, response) {
				var requestIndex = 0;

				var $this    = $(this);
				var $element = $(this.element);
				var jqXHR = $element.data('jqXHR');
				if(jqXHR)
					jqXHR.abort();

                var term=request.term.replace(/\+/,"%2b");
                term=term.replace(/\-/,"%2d");
                term=term.replace(/\./,"%2e");

				$element.data('jqXHR',$.ajax({
				 url: "?ACTION=514&id=6",
				 data: "term=" + escape(term),
				 processData: false,
				 contentType: "application/json; charset=ISO-8859-1",
				 dataType: "json",
				 async: true,
				 autocompleteRequest: requestIndex += 1,
				 complete: function() {
					$this.removeData('jqXHR');
					//response({});
				 },
				 success: function (data, status) {
				  if (this.autocompleteRequest === requestIndex) {
				  response(data);
				  }
				 },
				 error: function () {
				  if (this.autocompleteRequest === requestIndex) {
				   response([]);
				  }
				 }
				})
				);
			   },
			   select   : function( event, ui ) {
                        searchselected = true;
    					$("#quicksearch").val(ui.item.label);
						var values=ui.item.id.split("#");
						var groupid  =values[1];
						var articleid=values[0];

						var link='index.html';
						if(groupid !== ''){
							link+='?ACTION=2;GROUPID='+groupid+';SEARCH='+encodeURI(($("#quicksearch").val().replace(";",'%3b')));
						}else{
							link+='?ACTION=3;ARTICLE='+articleid+';SEARCH='+encodeURI(($("#quicksearch").val().replace(";",'%3b')));
						}
						window.location = (link);
					}	  
			});
		$("#quicksearch").attr('maxlength','80');
		$("#quicksearch").keydown(function(e) {
			if( e.keyCode === 13 && !searchselected ) {
				FRSubmit((this));
			}
	});

    $("#quicksearch_new").attr('maxlength','80');
    $("#quicksearch_new").keydown(function(e) {
        if( e.keyCode === 13 && !searchselected ) {
            FRSubmit((this));
        }
    });
    
    var qsxhr;
        $("#quicksearch_new").blur(function(event){
            if($("#qsresult").length > 0){
                $("#qsresult").delay(100).slideUp(300);//.remove();
            }
        });
        
		$("#quicksearch_new").keydown(function(event){
            var key= event.keyCode;
            if(key == 13){
                qsselector(key);
                return(false);
            }
        })

		$("#quicksearch_new").keyup(function(event){
            var key= event.keyCode;
            if(key == 13){
                qsselector(key);
                return(false);
            }else if(key > 36 && key < 41){
                qsselector(key);
                return(false);
            }else{
            
                var query = $(this).val();
                if($("#qsresult").length > 0){
                    $("#qsresult").remove();
                }

                if(query.length > 2){

                    if(qsxhr && qsxhr.readyState != 4){
                        qsxhr.abort();
                    }                
                    var term=query.replace(/\+/,"%2b");
                    
                    qsxhr = $.ajax({
                        url: "?ACTION=514&id=8",
                        data: "term=" + term,
                        processData: false,
                        contentType: "application/json; charset=ISO-8859-1",
                        dataType: "json",
                        async: true,
                        complete: function() {
                        },
                        success: function (data, status) {
                            update_search(data);
                        },
                        error: function () {
                          // response([]);
                        }
                     });               
                }
//            alert(query);
            }
        });
        
    function update_search(data){
        qsselected=1;
        
        $("#searchwrapper").append('<div id="qsresult" class="clearfix"></div>');
        $("#qsresult").append('<div class="gresult"></div>');
        $("#qsresult").append('<div class="aresult"></div>');

        $(".aresult").append('<p class="clearfix"><b>'+$("#lang_PRODUCTSUGGESTIONS").text()+"<br/></b></p>");

        var count=0;
        for(var term in data.response.docs){
            if(count < 6){
                var link='?ACTION=3;ARTICLE='+data.response.docs[term].article_artid+';SEARCH='+encodeURI(($("#quicksearch_new").val().replace(";",'%3b')));
                
                $(".aresult").append('<a href="'+link+'"><img src="https://www.reichelt.de/artimage/resize_30x30/'+data.response.docs[term].article_artid+'"><b>' + data.response.docs[term].article_artnr + '</b><small>'+ data.response.docs[term].article_lang_besch +"</small></a>");

//                $(".aresult").append('<a href="'+link+'"><b>' + data.response.docs[term].article_artnr + '</b><small>'+ data.response.docs[term].article_de_besch +"</small></a>");

                count++;
            }else{
                break;
            }
        }
        
        $(".gresult").append("<p><b>"+$("#lang_CATEGORIES").text()+"</b></p>");
        var count=0;
        var namen;        
        
        //hiiiiiiiiier

        for(icount=0; icount < data.facet_counts.facet_fields.article_lang_group_name.length ; icount+=2){
            if(count < 7){
                if(data.facet_counts.facet_fields.article_lang_group_name[icount+1] > 0){
                    namen=data.facet_counts.facet_fields.article_lang_group_name[icount].split("#");
                    
                    var link='index.html?ACTION=446;GROUPID='+namen[0]+';SEARCH='+encodeURI(($("#quicksearch_new").val().replace(";",'%3b')));
                    $(".gresult").append('<a href="'+link+'">' + namen[1] +' (' + data.facet_counts.facet_fields.article_lang_group_name[icount+1] +  ')' + "</a>");
                    count++;
                }
            }else{
                icount = data.facet_counts.facet_fields.article_lang_group_name.length
            }
        }
        
        // Hersteller
        //manufacturer_name        
        $(".gresult").append("<p style=\"padding-top:5px;\"><b>"+$("#lang_MANUFACTURER").text()+"</b></p>");
        var count=0;
        var namen;        
        
        for(icount=0; icount < data.facet_counts.facet_fields.manufacturer_name.length ; icount+=2){
            if(count < 6){
                if(data.facet_counts.facet_fields.manufacturer_name[icount+1] > 0){
                    namen=data.facet_counts.facet_fields.manufacturer_name[icount];//.split("#");
                    if(namen != 'FREI'){
                        var link='?ACTION=103;MANUFACTURER='+namen;//+';SEARCH=*';//+encodeURI(($("#quicksearch_new").val().replace(";",'%3b')));
//                        $(".gresult").append('<span jump-link="'+link+'">' + namen +' (' + data.facet_counts.facet_fields.manufacturer_name[icount+1] +  ')' + "</span>");
                        $(".gresult").append('<a href="'+link+'">' + namen + "</a>");
                        count++;
                    }
                }
            }else{
                icount = data.facet_counts.facet_fields.manufacturer_name.length
            }
        }
        
        
        $("a","#qsresult").each(function(){
            $(this).click(function(event){
                window.location = ($(this).attr('href')); 
                return(false);
            });
        });
        
//        $("a",".aresult").each(function(){
//            $(this).click(function(event){
//                window.location = ($(this).attr('href')); 
//                return(false);
//            });
//        });
        
    }    

    var qsselected      = 1;
    var qsswitch        = 0;
    var qsselectedclass = 'aresult';

    function qsselector(key){
        var selected = $(".qsselected");
        var add = 0;
        
        if(key == 37){
            $(".qsselected").removeClass('qsselected');
            qsswitch=1;
            qsselected=1;
            qsselectedclass = 'gresult'            
        }else if(key == 39){
            $(".qsselected").removeClass('qsselected');
            qsswitch=1;
            qsselected=1;
            qsselectedclass = 'aresult'            
        }
        
        if(key == 38 || key == 40){
            if(selected.length > 0){
                if(key == 38){
                    add = -1;
                    if(qsselected < 2){
                        add = 0;
                    }
                }
                if(key == 40){
                    add = 1;
                    if(qsselectedclass == 'aresult'){
                        if(qsselected+1 > $("."+qsselectedclass+" a").length){
                            add = 0;
                        }
                    }else{
                        if(qsselected+1 > $("."+qsselectedclass+" a").length){
                            add = 0;
                        }
                    }
                }
            }else{
                add = 0;
            }
        }
//        if(add != 0 || qsswitch != 0){
            qsswitch = 0;
            $("."+qsselectedclass+"> a:nth-of-type("+(qsselected)+")").removeClass('qsselected');
            qsselected += add;
//            alert(qsselectedclass);
            $("."+qsselectedclass+" > a:nth-of-type("+(qsselected)+")").addClass('qsselected');
//        }
        
        if(key == 13){
            if(qsselected > 1){
//                window.location = ($("."+qsselectedclass+" > :nth-child("+qsselected+")").attr('jump-link'));
                window.location = ($("."+qsselectedclass+" > a:nth-of-type("+qsselected+")").attr('href'));
                return(false);
            }
        }
    }


	$("#searchwrapper").keydown( function(e) {
                     if(e.which === '13') {
      			e.preventDefault();         		
                        //alert('hey, ho, let�s go');             
                       $('#searchbutton').click();
                        return false;
                    }
                
         });      
               
	$(".ui-helper-hidden-accessible").hide();
    
    $(".morekat").each(function(){
        $(this).find(".off").hide();
        $(this).click(function(e){
            if($(this).prev().attr('size')==10){
                $(this).prev().attr('size',$(this).attr('count'));
                $(this).find(".more_view").val($(this).prev().attr('id'));
                $(this).find(".off").show();
                $(this).find(".on").hide();
            }else{
                $(this).prev().attr('size',10);                  
                $(this).find(".more_view").val('');
                $(this).find(".off").hide();
                $(this).find(".on").show();
            }
            return(false);
        })
    });

    $("select[name='groupselect[]']").click(function(e){
        $("form[name='contentform']").submit();
    });
    
    $("input[name='groupselect[]']").click(function(e){
        $("form[name='contentform']").submit();
    });

    $("#noscriptsubmit").hide();

    $(".morepropcheck").each(function(){
        $(this).parent().parent().find(".hidden").hide();
        $(this).find(".off").hide();
        
        $(this).click(function(e){
//            var select=$(this).prev();
//            var id=select.attr('id');

            $(this).parent().parent().find(".hidden").toggle();
            
            if($(this).find(".more_view").val() == ''){
                $(this).find(".off").show();
                $(this).find(".on").hide();
                $(this).find(".more_view").val($(this).parent().parent().attr('id'));
            }else{
                $(this).find(".off").hide();
                $(this).find(".on").show();
                $(this).find(".more_view").val('');
            }
            return(false);
        })
    });
    
    $(".pre_more_view").each(function(){
        if($(this).val() != '' ){
            $("#"+$(this).val()).find(".morepropcheck").trigger('click');
        }
    });
        

    $(".moreprop").each(function(){
        $(this).find(".off").hide();
        
        $(this).click(function(e){
//            var select=$(this).prev();
//            var id=select.attr('id');
            
            if($(this).prev().attr('size')==4){
                $(this).prev().attr('size',$(this).attr('count'));
                $(this).find(".more_view").val($(this).prev().attr('id'));
                $(this).find(".off").show();
                $(this).find(".on").hide();
            }else{
                $(this).prev().attr('size',4);                  
                $(this).find(".more_view").val('');
                $(this).find(".off").hide();
                $(this).find(".on").show();
            }
            return(false);
        })
    });
    
    $(".pre_more_view").each(function(){
        if($(this).val() != '' ){
            $("#"+$(this).val()).next().trigger('click');
        } 
    });

    $("#newpropselect input").each(function(){
        $(this).click(function(e){
           $("input[name='START']").val(0);
           // Hier !!!!
            delay(function(){
                var jump = getUrlParameter('makeurl');
                if(jump == 'true'){
                    var mylocation = window.location.href;
                    var myurl    = mylocation.replace(/SID.*/g,'');
                    var myurl    = myurl.replace(/&propselect=.*/g,'');
                    // Auskommentieren!!!!!!!
                    window.location.href = myurl+buildURL();
                    return(false);
                }else{
                $("form[name='contentform']").submit();
                }
            }, 1200 );
        })
    });


    $("#newpropselect option").each(function(){
        $(this).click(function(e){
            var name = $(this).parent().attr('name');
            if($("input[name='"+name+"'][value='"+$(this).val()+"']") &&  $("input[name='"+name+"'][value='"+$(this).val()+"']").val() != undefined){
                $(this).attr("selected", false);
                $("input[name='"+name+"'][value='"+$(this).val()+"']").val('');
            }else{
                var bg = $(this).css("background-image");
                if(bg.includes("checked")){
                    $(this).attr("selected", false);
                    var val=$(this).val();
                    var vals=val.split("#");
                    
                    var butname='delete_'+vals[0]+'#'+vals[1];
                    $("button[value='"+butname+"']").trigger('click');
                }
                $(this).attr("selected", "selected");
            }
            
            $("input[name='START']").val(0);
//            $("input[name='OFFSET']").val(16);
            $("form[name='contentform']").submit();
        })
    })

    $("#variantselect select").change(function(e){
        window.location = $(this).val();
    });
    
//    $("#newpropselect select").change(function(e){
//        var url=$("input[name='propurl']","#propselect").val();
//        url=url+encodeURIComponent($(this).val());
//        window.location = url;
//
//        $("input[name='START']").val(0);
//        $("input[name='OFFSET']").val(16);
//        $("form[name='contentform']").submit();
//    });
    
    
    if($("input[name='MAXOPEN']")){
        var i = parseInt('0'+$("input[name='MAXOPEN']").val());
//        alert(i);

        $(".more_filter[name='open_"+(i+1)+"'] .sopen").show();
        $(".more_filter[name='open_"+(i+1)+"'] .sclose").hide();

        while(i > 0){
            $(".open_"+i).show();
            $(".more_filter[name='open_"+i+"']").attr('open','open');
            $(".more_filter[name='open_"+i+"'] .sopen").hide();
            $(".more_filter[name='open_"+i+"'] .sclose").show();
            i--;
        }
    }
		
    $(".more_filter").each(function(){
        $(this).click(function(e){
            var name=$(this).attr('name');
            var res = name.split('_');
            var i=parseInt(res[1]);
            var maxopen=parseInt($("input[name='MAXOPEN']").val());
            $(".more_filter[name='open_"+(i+1)+"'] .sopen").show();
            $(".more_filter[name='open_"+(i+1)+"'] .sclose").hide();
//            alert((".more_filter[name='open_"+(i+1)+"'] .sclose"));
            
            if($(this).attr('open') == 'open'){
                $("input[name='MAXOPEN']").val(i-1);
                while(i <= maxopen){
                    $(".open_"+i).hide();
                    $(".more_filter[name='open_"+i+"']").removeAttr('open');
                    $(".more_filter[name='open_"+i+"'] .sopen").show();
                    $(".more_filter[name='open_"+i+"'] .sclose").hide();
                    i++;
                }
            }else{
                $("input[name='MAXOPEN']").val(i);
                while(i > 0){
                    $(".open_"+i).show();
                    $(".more_filter[name='open_"+i+"']").attr('open','open');
                    $(".more_filter[name='open_"+i+"'] .sopen").hide();
                    $(".more_filter[name='open_"+i+"'] .sclose").show();
                    i--;
                }
            }
            return(false);
        })
    });    
        
	/**
	 * init the Plugins
	 */
	// Add to Basket for the "intocart" Buttons
//	if (!($.browser.msie && $.browser.version < 8)) {  // all under 8 doesn�t work with webtrekk wt.
//		$('input[name^="Uebernehmen"], input[name^="anzahl"], input[name^="Insert"]').addToBasket(); // Insert f�r ContentEditor
		$('input[name^="Uebernehmen"], input[name^="anzahl["]').addToBasket();
//	}

    $('<div class="quantity-nav"><div class="quantity-button quantity-up">+</div><div class="quantity-button quantity-down">-</div></div>').insertAfter(".quantity input[type='number']");
    $('.quantity').each(function () {
        var spinner = $(this),
                input = spinner.find('input[type="number"]'),
                btnUp = spinner.find('.quantity-up'),
                btnDown = spinner.find('.quantity-down'),
                min = input.attr('min'),
                max = input.attr('max');

        btnUp.click(function () {
            var oldValue = parseFloat(input.val());
            if (oldValue >= max) {
                var newVal = oldValue;
            } else {
                var newVal = oldValue + 1;
            }
            spinner.find("input[type='number']").val(newVal);
            spinner.find("input[type='number']").trigger("change");
            spinner.find("input[type='number']").trigger("focusout");
//            updateDelayView();
        });

        btnDown.click(function () {
            var oldValue = parseFloat(input.val());
            if (oldValue <= min) {
                var newVal = oldValue;
            } else {
                var newVal = oldValue - 1;
            }
            spinner.find("input[type='number']").val(newVal);
            spinner.find("input[type='number']").trigger("change");
            spinner.find("input[type='number']").trigger("focusout");
//            updateDelayView();
        });
    });
   
    // +- Buttons    
    $('.bsktplgn').each(function(){
        $(this).addToBasket();
    });
    
	$('#basket').flyingBasket();
	
	//Placeholder f�r �ltere Browser (IE)
//	if (!($.browser.mozilla)) {
//		$('input, textarea').placeholder();
//	}
	
	// selectCountry
	$('#selectCountry, #notmycountry').each(function(){
		var requesturl = "?ACTION=517&ID=68";
		var search = $('#quicksearch').val();
		if(search !== '') {
			requesturl += "&SEARCH=" + search;
		}
		$(this).overLayer({
		requesturl	: requesturl,
		dataType	: "html",
		});
        
	});
    
    $('#payment_data input.submitclass').click(function(){
        $('input',$(this).parent().parent()).attr("checked","checked");
    });
    
    
    // CCOUNTRY per Browsercookiesetzen nicht korrekt, daher hier ausb�geln:
//    if ($.browser.msie){
//        document.cookie = 'ccountry=; expires=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
//        document.cookie = 'CCOUNTRY=; expires=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
//    } else {
        document.cookie = 'ccountry=; expires=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        document.cookie = 'CCOUNTRY=; expires=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
//    }
    
    
	// nicht sauber aber m�glich
	u = window.location.host;
	if (u.indexOf("reichelt.com") > 0){
		results = document.cookie.match ( '(^|;) ?' + 'docountryselect' + '=([^;]*)(;|$)' );
		if ( results ){
			$('#selectCountry').trigger('click');
			var expires = new Date();
			expires.setTime(expires.getTime() - 1000);
			if (navigator.appName == 'Microsoft Internet Explorer'){
				document.cookie = 'docountryselect=; expires='+ expires.toGMTString() + ';';
			} else {
                document.cookie = 'docountryselect=; expires='+ expires.toGMTString() + ';domain=.reichelt.com;path=/';
			}
		}
	}else{
        
        /* ccountry sollte hier nicht verwendet werden da es mit CCOUNTRY kollidieren k�nnte
        */
       
        //setCookie('ccountry',country);
//        var ccountry=getCookie('ccountry');
//        var cdn     =getCookie('CDNallowed');
//        var country = 'DE';
//        
//        var urlcountry=$.getUrlVar('CCOUNTRY');
//        if(urlcountry > 0){
//            ccountry =urlcountry;
//            country  =urlcountry;
//        }
//        
//        if(ccountry == undefined && cdn != undefined){
//            $.getJSON( "?ACTION=514&ID=69", function( json ) {
//                if(json.ask){
//        			$('#selectCountry').trigger('click');
//                    country=json.country;
//                }
//            });            
//        }
//        var expires = new Date();
//        expires.setTime(expires.getTime() + 60*60*24*365*1000);
//        if ($.browser.msie){
//            document.cookie = 'ccountry='+country+'; expires='+ expires.toGMTString() + ';';
//        } else {
//            document.cookie = 'ccountry='+country+'; expires='+ expires.toGMTString() + ';path=/';
//        }
    }

// nur bei ontouch
		if(!('ontouchstart' in window)){//check for touch device
//			$.each($('.rootgroups'), function(){$(this).extendMainNavis();});
			$('.rootgroups').extendMainNavi();
			$("#quicksearch").focus();
		}
	$('#closeButton').click(function(){
		$(this).parent().hide('slide',{direction:'right'},1000)
						.fadeOut();
	});
        
		
	// Menu Infobox:
	$d = $("#menu_infobox");
	$d.addClass("snip");
	$d.find('#expand').click(function(){$d.removeClass('snip')});
	
	// youtubepopoup f�r einige L�nder "we talk electro"
	$('.popup-youtube').magnificPopup({
		disableOn: 700,
        type: 'iframe',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        preloader: false,
        fixedContentPos: false
	});
	
//InfoButton bzw. Artikelstatus
    //Hilfeseite per iframe/inline
		$('.help').magnificPopup({   
		   type: 'iframe',                    
		   iframe: {
			   patterns: {
				   local_video: {       
				   index: 'index.php?ACTION=',
				   id: 'ACTION=',                         
				   src: 'index.php?ACTION=%id%'
				 }
			   },
			   tError: 'Page could not be loaded.'
		   }     
	   });

	   // Energylabel
	   $('.energyefficency, .genergyefficency, .lenergyefficency').magnificPopup({   
		   type: 'iframe',                    
		   iframe: {
				patterns: {
					yourcustomsource: {       
					index: 'index.php?ACTION=',
					id: 'ACTION=',                         
					src: 'index.php?ACTION=%id%'
				}
			   },
			   tError: 'Page could not be loaded.'
		   }     
	   });

	   // Energylabel
//	   $('.energyefficency, .genergyefficency, .lenergyefficency').magnificPopup({   
//		   type: 'image',
//		   closeOnContentClick: true,
//		   image: {
//			   verticalFit: true
//		   }
//	   });
                
   //fuer billpay
       $('#billpaypopup').magnificPopup({   
                    type: 'iframe',                    
                    iframe: {
                        patterns: {
                            local_video: {       
                            src: 'index.php?ACTION=%href%'
                          }
                        },
                        tError: 'Page could not be loaded.'
                    }     
                });
                
                
//    if($("#av_avaiability")){
//        $("#av_avaiability").each(function(){
//            rootelem = this;
//            artid = $(this).attr('name');
//            var url = "?ACTION=514&ID=70&ARTICLE=" + artid;
//            $.ajax({
//                    url: url,
//                    contentType : "application/html; charset=UTF-8",
//                    dataType    : "html",
//                    cache       : false,
//                    async       : true,
//                    processData : false,
//                    success: function(updateData, textStatus) {
//                        $(rootelem).after(updateData);
//                    }			
//                });
//        });
//    };


});

    // Zur Performanceoptimierung einige Funktionen erst nach Document Load
    $(window).load(function() {
        /*
         * quicknewsletteranmeldung 
         */
        var form        = '.newsletter',
        className   = 'newsletter--active',
        email       = 'input[type="email"]';
 
        $(form).each( function()
        {
            var $form   = $(this),
                $email  = $form.find(email),
                val     = '';

            $email.on( 'keyup.addClassWhenEmail', function()
            {
                val = $email.val();
                $form.toggleClass( className, val !== '' && /^([\w-\.]+@([\w-]+\.)+[\w-]{2,12})?$/.test( val ) );
            });
//                alert(val);
                $form.find('input[type="submit"]').click(function(event){
                    event.preventDefault();
                    var pdata = $('.newsletter').serialize();
                    if(pdata == ''){
                        pdata = 'MYEMAIL='+val;
                    }
//                    alert(pdata);
                    if(val !== '' && /^([\w-\.]+@([\w-]+\.)+[\w-]{2,12})?$/.test( val )){
                        $.ajax({
                            type: "POST",
                            url: "?ACTION=514&ID=71",
                            data: pdata,
                            success: function(updateData, textStatus){
                                if (updateData.return === 'occupied') {
                                    alert($('#newsinfo_1').html());
                                } else if (updateData.return === 'ready') {
                                    alert($('#newsinfo_2').html());
                                    $('.newsletter').remove();
        //                            $('.newsletter').replaceWith('<span>Eintrag erfolgreich. Bitte best�tigen Sie den Link in der Best�tigungsemail.....</span>');
                                } else {
                                    alert($('#newsinfo_2').html());
        //                            alert(updateData.return);
                                }
                            }
                          });
                    }else{
                        alert($('#newsinfo_3').html());
                    }
                })
        });
        
        
        
        /*
        * Zum Seitenanfang springen 
        */
    if(document.body.offsetHeight > 1200 && $('#orderheader').length == 0) {
        $('#wrapper').append('<div id="jumptotop" class="greyBorder">\n\
                        <a href="javascript:scroll(0,0)">' + $('#lang_topofpage').html() +
//                    (($('meta[name=language]').attr("content") === 'de')?'Seitenanfang':'top of the page') + 
                    '  &#9650;</a>\n\
                        </div>');
        var jumptotop = $('#jumptotop');
        var footery = '';

        $(window).scroll(function(){
            if(footery == '') {
                footery = $('#footer').offset();
            }
            if (window.pageYOffset > 200) {
                jumptotop.show();
                if(footery.top < window.pageYOffset + window.innerHeight) {
                    jumptotop.css('position', 'absolute');
                } else {
                    jumptotop.css('position', 'fixed');
                }
            } else {
                jumptotop.hide();

            }
        });
    };
    
    $('.adw_swiper-container').each(function(index, element){
        slidespercolumn = $(this).attr('data-swiper-slidespercolumn');
        var adwswiper = new Swiper(this, {
                                scrollbar: { el: '.swiper-scrollbar', draggable: true},
                                lazy: {
                                    loadPrevNext: true
                                  },
                                slidesPerColumn: slidespercolumn,
                                slidesPerView: 4,
                                slidesPerGroup: 4,
                                spaceBetween: 0, // Andere Werte haben nebeneffekte
                                grabCursor: true,
                                navigation: {
                                            nextEl: '.swiper-button-next',
                                            prevEl: '.swiper-button-prev',
                                          }
                            }); 
    });
    
    $('.magaz-swiper-container').each(function(index, element){
        var swipermagaz = new Swiper(this, {
          direction: 'vertical',
    //      slidesPerColumn: 4,
          slidesPerView: 'auto',
          grabCursor: true,
          scrollbar: {
            el: '.swiper-scrollbar',
            draggable: false,
            snapOnRelease: true,
    //        hide: true
          },
          mousewheel: true,
        });
    });
   
    
    /**
     * Shopauskunft
     */
    if ($('#bewertung').length > 0) {
        domWrite("bewertung", "https://apps.shopauskunft.de/seal/b357a6af5138575b32a693d380225613.js", "");
    }
    /**
     * 
     */
    $('#mostbuyedtogether').each(function(){
        artid = $(this).attr('name');
        mostbuyedtogethermother = this;
        var url = "?ACTION=517&ID=7&ARTICLE=" + artid;
		$.ajax({
				url: url,
				contentType : "application/html; charset=UTF-8",
				dataType    : "html",
				cache       : false,
				async       : true,
				processData : false,
				success: function(updateData, textStatus) {
                    $(mostbuyedtogethermother).append(updateData);
				}			
			});
    });
    
//    /**
//     * Recommendations
//     */
    $('#recommwrapper').each(function(){
        recommother = this;
        var url = "?ACTION=517&ID=6";
		$.ajax({
				url: url,
				contentType : "application/html; charset=UTF-8",
				dataType    : "html",
				cache       : false,
				async       : true,
				processData : false,
				success: function(updateData, textStatus) {
                    $(recommother).append(updateData);
				}			
			});
    });
// expandarticledescription    
//    $('.expandartdesc, #boxLinks a').click(function(){
//        $('#av_tabprod').removeClass('teaserme');
//        $('.expandartdesc').remove();
//    });
//    if ($('.expandartdesc').length > 0){
//        if($('#av_tabprod').innerHeight() > 300 ){
//            $('#av_tabprod').addClass('teaserme');
//            $('.expandartdesc').show();
//        }
//    }
    /**
     * Meistgekauft mit
     */
//    if (!($.browser.msie && $.browser.version < 10)) {  // all under 10 doesn�t work with the swiper
    if (!(window.navigator.userAgent.indexOf("MSIE ") > 0 && window.navigator.userAgent.indexOf("MSIE ") < 10)) {  // all under 10 doesn�t work with the swiper
        $('#mostbuyedwith_placeholder').each(function(){
            artid = $(this).attr('name');
            mostbuyedmother = this;
    //        var url = "?ACTION=517&ID=5&ARTICLE=" + artid;
            var url = "?ACTION=517&ID=10&ARTICLE=" + artid;
            $.ajax({
                    url: url,
                    contentType : "application/html; charset=UTF-8",
                    dataType    : "html",
                    cache       : false,
                    async       : true,
                    processData : false,
                    success: function(updateData, textStatus) {
                        $(mostbuyedmother).append(updateData);
                            var alsoboughtswiper = new Swiper('.alsobought_swiper-container', {
                                scrollbar: { el: '.swiper-scrollbar', draggable: true},
                                slidesPerView: 'auto',
                                slidesPerGroup: 1,
    //                            centeredSlides: true,
                                spaceBetween: 0, // Andere Werte haben nebeneffekte
                                grabCursor: true,
                                navigation: {
                                            nextEl: '.swiper-button-next',
                                            prevEl: '.swiper-button-prev',
                                          }
                            });
                    }			
                });

        });
    };

    /*
     * Dynamisches Nachladen von Zubeh�rartikeln
     */
    $('#addonsplaceholder').each(function(){
        
        // IE < 9 haben Probleme
        if (/MSIE (\d+\.\d+);/.test(navigator.userAgent)){ //test for MSIE x.x;
            var ieversion=new Number(RegExp.$1) // capture x.x portion and store as a number
        }
        if(typeof ieversion == 'undefined' || ieversion > 8) {
            
            addonsplaceholder = this;
            var url = "?ACTION=517&ID=8&ARTICLE=" + $(this).attr('name');
            window.onscroll =function(){
                if ((window.pageYOffset + window.innerHeight + 500) > Math.round($(addonsplaceholder).offset().top)) {
                    window.onscroll = null;
                    $.ajax({
                            url: url,
                            contentType : "application/html; charset=UTF-8",
                            dataType    : "html",
                            cache       : false,
                            async       : true,
                            processData : false,
                            success: function(updateData, textStatus) {
                                $(addonsplaceholder).append(updateData);
                            }			
                        });
                }
            }
        }

    });
    
    
//    var $pageheader = $('#pageheader_02');
    var $wrapper = $('#wrapper');
    function parallax(e){
//        window.removeEventListener('scroll', parallax);
//        alert($pageheader.scrollTop());
//console.log($(window).scrollTop())
        if ($(window).scrollTop() > 184) {
//            alert('testr');
//            $pageheader.addClass("sticky-search");
            $wrapper.addClass("stickyheader");
            
          } else {
//            $pageheader.removeClass("sticky-search");
            $wrapper.removeClass("stickyheader");
          }
        
    }
       
    window.addEventListener('scroll', parallax);

    
    /*
     *  Icons switch
     */

    $('#pictogramm li.pre').each(function(){
        $(this).bind('mouseover' , function() {
                   $(this).next('.post').show();
                   $(this).hide();
               })
    })
    $('#pictogramm li.post').each(function(){
        $(this).bind('mouseleave', function(){
                   $(this).prev('.pre').show();
                   $(this).hide();
                })
    })
                
    $('#addtolist input[type="button"]').each(function(){
        $(this).click(function(){
               
            var listid = $('#addtolist select[name="addtolist_list"]').val();
            var artid  = $('#addtolist input[name="addtolist_artid"]').val();
            var anzahl = $('#addtolist input[name="anzahl['+artid+']"]').val();
        
            if(anzahl == undefined){
                anzahl=1;
            }
            
            var urlparams = '&artid='+artid+'&anzahl='+anzahl+'&sort=0&listid='+listid;

                 $.ajax({
		   url: "?ACTION=514&ID=26"+ urlparams,
//                 data: params,
                   type: "POST",
				contentType : "application/json; charset=ISO-8859-1",
				dataType    : "json",
				cache       : false,
				async       : true,
				processData : false,
				success: function(updateData, textStatus) {
					alert('OK');
                                }
    });
        })
    })
    
    $('#reevoo a').each(function(){
        $(this).click(function(){
            createCookie("reevoo_off", "1", 365); 
            $('#reevoo').hide();
        })
        var $off = readCookie("reevoo_off");
        if ($off == '1'){
            $('#reevoo').hide();
        }
    });
    
    $('.reevoo iframe').each(function(){
//        alert($(this).src);
//        $(this).attr('src', 'AGB.txt');
        $(this).attr('src', $(this).attr('psrc'));
    });
});    
    /*
    

 var urlparams = '&Uebernehmen[' + artid + ']=' + anzahl + '&anzahl[' + artid + ']=' + anzahl + '&ARTID=' + artid + '&anzahl_alt[' + artid + ']=' + anzahl_alt + SIDparam+trst;
//            var params = {
////                            "Uebernehmen['" + artid + "']":anzahl,
////                            TABLENAME:$seofield.attr('data-tablename'),
////                            COLUMNAME:$seofield.attr('data-columnname'),
////                            FIELDID:$seofield.attr('data-id'),
////                            FIELDCONTENT:content
//                              SID:$.getUrlVar('SID')
//                        };
            
			$.ajax({
				url: "?ACTION=514&ID=12"+ urlparams,
//                data: params,
                type: "POST",
				contentType : "application/json; charset=ISO-8859-1",
				dataType    : "json",
				cache       : false,
				async       : true,
				processData : false,
				success: function(updateData, textStatus) {
//					alert('fertig!!');


    */

})(jQuery);


var delay = (function(){
  var timer = 0;
  return function(callback, ms){
    clearTimeout (timer);
    timer = setTimeout(callback, ms);
  };
})();

//function setNewCookie(){
//    createCookie("NewVersion", "1", 20); 
//    location.reload();
//}
//
//function unsetNewCookie(){
//    createCookie("NewVersion", "0", 20); 
//    location.reload();
//}


// Cookies
function createCookie(name, value, days) {
    if (days) {
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        var expires = "; expires=" + date.toGMTString();
    }
    else var expires = "";               

    document.cookie = name + "=" + value + expires + ";domain=.reichelt.de;path=/";
}

function readCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
    }
    return null;
}
        
var getUrlParameter = function getUrlParameter(sParam) {
    var sPageURL = decodeURIComponent(window.location.search.substring(1)),
        sURLVariables = sPageURL.split('&'),
        sParameterName,
        i;

    for (i = 0; i < sURLVariables.length; i++) {
        sParameterName = sURLVariables[i].split('=');

        if (sParameterName[0] === sParam) {
            return sParameterName[1] === undefined ? true : sParameterName[1];
        }
    }
};        


var buildURL = function buildURL(){
    var url="&propselect=";

    var proparray = new Array();
    
    $("[name^=propselect]").each(function(){
        if($(this).attr('checked') == 'checked'){
//            var i = $(this).attr('id').replace(/^prop_([0-9]*).*/g,'$1');
//        $(this).find('option').each(function(index,element){        
//            if($(this).attr('selected') && index > 0){
                var myvalues = $(this).attr('value').split('#');
                var i = myvalues[0];
                if(!proparray[i]){
                    proparray[i]=new Array();
                }
                var myvalues = $(this).attr('value').split('#');
                proparray[i].push(Base64.encode(encodeURIComponent(myvalues[4])));
//            }
//        })
        }
    })
    
    for(var index in proparray){
        url+='*'+(index*10)+'_';
        for(var value in proparray[index]){
            url+='|'+proparray[index][value];
        }
    }
  return(url);
};

var Base64 = {_keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", encode: function (e) {
        var t = "";
        var n, r, i, s, o, u, a;
        var f = 0;
        e = Base64._utf8_encode(e);
        while (f < e.length) {
            n = e.charCodeAt(f++);
            r = e.charCodeAt(f++);
            i = e.charCodeAt(f++);
            s = n >> 2;
            o = (n & 3) << 4 | r >> 4;
            u = (r & 15) << 2 | i >> 6;
            a = i & 63;
            if (isNaN(r)) {
                u = a = 64
            } else if (isNaN(i)) {
                a = 64
            }
            t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a)
        }
        return t
    }, decode: function (e) {
        var t = "";
        var n, r, i;
        var s, o, u, a;
        var f = 0;
        e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
        while (f < e.length) {
            s = this._keyStr.indexOf(e.charAt(f++));
            o = this._keyStr.indexOf(e.charAt(f++));
            u = this._keyStr.indexOf(e.charAt(f++));
            a = this._keyStr.indexOf(e.charAt(f++));
            n = s << 2 | o >> 4;
            r = (o & 15) << 4 | u >> 2;
            i = (u & 3) << 6 | a;
            t = t + String.fromCharCode(n);
            if (u != 64) {
                t = t + String.fromCharCode(r)
            }
            if (a != 64) {
                t = t + String.fromCharCode(i)
            }
        }
        t = Base64._utf8_decode(t);
        return t
    }, _utf8_encode: function (e) {
        e = e.replace(/\r\n/g, "\n");
        var t = "";
        for (var n = 0; n < e.length; n++) {
            var r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r)
            } else if (r > 127 && r < 2048) {
                t += String.fromCharCode(r >> 6 | 192);
                t += String.fromCharCode(r & 63 | 128)
            } else {
                t += String.fromCharCode(r >> 12 | 224);
                t += String.fromCharCode(r >> 6 & 63 | 128);
                t += String.fromCharCode(r & 63 | 128)
            }
        }
        return t
    }, _utf8_decode: function (e) {
        var t = "";
        var n = 0;
        var r = c1 = c2 = 0;
        while (n < e.length) {
            r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
                n++
            } else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                n += 2
            } else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                n += 3
            }
        }
        return t
    }}

    function showReevooInfo(url){
//        alert(url);

        $('#divwindow').append('<div class="inner_div"><a href="#" class="close">X</a><iframe src="'+url+'"></iframe></div>');
        $('#divwindow').attr("class","reevoo_div");
        $('#divwindow').fadeIn("slow");

        $("#divwindow .close").click(function () {
           $(this).parent().parent().fadeOut("slow");
           $('#divwindow').html('');
        });
    }
    
    function showMegaBanner(bannername, link, image, country, startDate, endDate){
        
        let dateStart = new Date(startDate);
        let dateEnd = new Date(endDate);
        
        if(Date.now() <= dateStart){
            return;
        }
        if(Date.now() >= dateEnd){
            return;
        }
        
        //console.log(bannername, link, image, country, startDateYear, startDateMonth, startDateDay, endDateYear, endDateMonth, endDateDay);
        //Abbruch wenn Cookie gesetzt und der Kunde damit den Banner weggeklickt hat 
       if(getCookie(bannername)=="dismiss"){   
           return;
       }
        // laender einschraenkung beachten
        if( country.indexOf(getUserSettingCountry()) <= -1 ){
            return;
        }
        // pr�fe ob startdatum gr��er gleich ist. wenn ja dann pr�fe ob enddatum kleiner gleich ist. wenn beides true dann mach weiter ansonsten abbrechen
        //console.log(startDate(startDateYear, startDateMonth, startDateDay));
        //console.log(endDate(endDateYear, endDateMonth, endDateDay));
        /*if(!startDate(startDateYear, startDateMonth, startDateDay)) {
            console.log('hallo10');
            return;
        }else { 
            if(!endDate(endDateYear, endDateMonth, endDateDay)) {
                console.log('hallo20');
                return;
            }
        }*/
       // Den Content anzeigen
       var content = '';
       content +=  '<a href="' + link + '" class="clearfix megabanner ' + bannername + '">\n\
                       <img src="' + image + '"/>\n\
                       <span id="close_bf"></span>\n\
                   </a>';
       //wo soll es angezeigt werden 
       $(content).insertAfter('#breadcrumb');

       //schlie�en und cookie setzen
       $('#close_bf').click(function(e){
           e.preventDefault();
           $('.'+ bannername).slideUp("slow");
           // Nur Sessioncookie
           document.cookie = bannername + "=dismiss";
       });

   }
   
   /*function startDate(startDateYear, startDateMonth, startDateDay) {
   
        const date = new Date();

        if ( (date.getFullYear() >= startDateYear) && (date.getMonth() >= startDateMonth -1) && (date.getDate() >= startDateDay) ) {
            return true;
        }
        return false;
    }
    
    function endDate(endDateYear, endDateMonth, endDateDay) {
   
        const date = new Date();

        if ( (date.getFullYear() <= endDateYear) && (date.getMonth() <= endDateMonth -1) && (date.getDate() <= endDateDay) ) {
            return true;
        }
        return false;
    }*/
   
   function getUserSettingCountry() {
        var usersettings = JSON.parse(document.getElementById('usersettings').innerHTML);
        return usersettings['country'];
    }
    
    function scrollTo(scrollToID) {
        $([document.documentElement, document.body]).animate({ 
            scrollTop: $( scrollToID ).offset().top
        }, 1000);
    }
    
    window.onload = function(){
        /* Loadbee tab einblenden und klick funktion erm�glichen */
        var loadbee = $( "iframe#loadbeeTabContent" ).get( 0 );
        if(typeof loadbee !== 'undefined'){
            document.getElementById("av_tabloadbee_a").style.display="block";
            document.getElementById("av_loadbee").style.display="block";
            document.getElementById("av_tabloadbee_a").onclick = function() {scrollTo('#av_loadbee');};
        }
        if(document.getElementById("article") && !document.getElementById("av_datasheetview")){
            document.getElementById("av_tabdata_a").style.display="none";
        }
    };
    
   
