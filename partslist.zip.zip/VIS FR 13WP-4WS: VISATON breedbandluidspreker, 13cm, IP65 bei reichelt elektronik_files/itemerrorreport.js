


constructed = false;
pressed = false;


function success (message, anchor) {
    
    $("#error_report_content").remove();
    //$("#error_report_close").remove();
    $("#error_report_arrow").remove();
    $("#error_report_window").append('<div id="error_report_success" class="error_report_success">'+message+'</div>');
    $("#error_report_container").css('top', anchor.parent().position().top + 180);
    $("#error_report_container").on("click", function () {
        $("#error_report_container").remove();
        constructed = false;
        pressed = false;
    });
    
}


function build_window ($url, $artid) {
    
    anchor = $("#av_linkbox");
        
    if (!constructed) {
        
        anchor.append('<div id="error_report_container" class="error_report_container" style="display:none"></div>');
         
        $("#error_report_container").append('<div id="error_report_window" class="error_report_window"></div>');
        //$("#error_report_container").append('<div id="error_report_arrow" class="error_report_arrow"></div>');
        $("#error_report_window").append('<div id="error_report_close" class="error_report_buttons">&#10006;</div>');
        $("#error_report_window").append('<div id="error_report_content" class="error_report_content"></div>');
        $("#error_report_content").load($url, function() {
            
            $("#error_report_container").css('top', anchor.parent().position().top - 50);
            
            $("#error_report_container").show();
            
            $("#error_report_confirm").on("click", function () {
                
                if (($.trim($("#error_report_input_comment").val()).length > 0) && (pressed == false)){
                    pressed = true;
                    //$.post("/General/ErrorReportInterface.php",
                    $.post("/?IW=1&JQUERY=1&ACTION=517&ID=31",
                    {
                      comment: $("#error_report_input_comment").val(),
                      email: $("#error_report_input_email").val(),
                      name: $("#error_report_input_name").val(),
                      artid: $artid
                    },
                    function(data,status){
                        
                        if (status === 'success') {
                        
                            success(data, anchor);
                           
                        }
                        
                    });
                    
                }

            });
            
        });
        
        $("#error_report_close").on("click", function () {
            $("#error_report_container").hide();
        });
        $("#error_report_window").draggable({
		  containment: "document",
		  zIndex:1000
		});
        constructed = true;
       
    } else {
        
        $("#error_report_container").show();
        
    }
    
}


