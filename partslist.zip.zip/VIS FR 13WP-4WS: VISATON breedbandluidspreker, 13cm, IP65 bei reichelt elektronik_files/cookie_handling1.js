comparestart();

function comparestart(){
	if(document.readyState != "complete") {
        window.setTimeout(comparestart, 100);
        return false;
    }else{
		precompared_artids  = decodeURIComponent(getCookie('compared_artids')).replace(/\+/g, ' ');
		precompared_array 	= precompared_artids.split(' ');
		for(i in precompared_array){
//			alert('compare_'+precompared_array[i]);
			if(document.getElementById('compare_'+precompared_array[i])){
				document.getElementById('compare_'+precompared_array[i]).checked=true;
			}
			if(document.getElementById('compareicon_'+precompared_array[i])){
                                document.getElementById('compareicon_'+precompared_array[i]).classList.add('aktiv');
                        }
		}
	}
}

function in_array(v,a){
    for(var g in a){
        if(a[g]==v){
            return g;
        }
    }
    return -1;
}

function getCookie(name){return(document.cookie.match('(^|; )'+name+'=([^;]*)')||0)[2];}

//function getCookie(name) {
//	if(document.cookie){
//		var cookies = unescape(document.cookie).split(';');
//        for(var i in cookies){
//        	var cookiename = cookies[i].split('=')[0];
//        	if(cookiename == ' '+name){
//        		value = cookies[i].split('=')[1];
//        		return(value);
//			}else{
//			}
//		}
//	}
//	return('');
//}

function setCookie(name,value,days) {
    
    var FQD = window.location.href;
    var domain = FQD.match(/reichelt\.([a-zA-Z]{2,3})\//);
    domain = domain[0].substr(0, domain[0].length-1);
    
    if (days) {
        var date = new Date();
    	date.setTime(date.getTime()+(days*24*60*60*1000));
    	var expires = '; expires='+date.toGMTString();
    }else{
        var expires = '';
    }
   	document.cookie = name+'='+value+expires+';domain=.'+domain+' ;path=/';
}

function setCompareArtCookie(artid){
	var compared_array  	  = new Array();
	var varcompared_artids    = '';
	var returncompared_artids = '';
	var found				  = false;
	
	varcompared_artids  = decodeURIComponent(getCookie('compared_artids')).replace(/\+/g, ' ');
	compared_array 		= varcompared_artids.split(' ');
	
	if(document.getElementById('compare_'+artid).checked){
		for(i in compared_array){
			if(artid == compared_array[i]){
				found=true;
			}else{
				if(returncompared_artids != ''){
					returncompared_artids = returncompared_artids+' '+compared_array[i];
				}else{
					returncompared_artids = compared_array[i];
				}
			}
		}
		if(!found){
			if(returncompared_artids != ''){
				returncompared_artids = returncompared_artids+'+'+artid;
			}else{
				returncompared_artids = artid;
			}
		}
	}else{
		returncompared_artids='';
		var plus='';
		for(i in compared_array){
			if(compared_array[i] != artid){
				returncompared_artids = returncompared_artids+plus+compared_array[i];
				plus=' ';
			}
		}		
	}
	setCookie('compared_artids',returncompared_artids,365);
}

function setArtCookie(artid){
    if(typeof(compared_article)!="undefined"){
        var pos=in_array(artid,compared_article)
        if(compared_article.length > 0){
            for(var i in compared_article){
                setCookie('compared_articles['+i+']','',-1);
                elem=document.getElementById('c_'+compared_article[i]);
                if(elem){
                    elem.checked=false;
                }
            }
        }
        if(pos>=0){
            compared_article.splice(pos,1);
        }else{
            compared_article.push(artid);
        }
        compared_article.sort;
/*        if(compared_article.length>4){
            compared_article=compared_article.slice(1);
        }*/
//        for(i=0;i<compared_article.length;i++){
		var j=0;
        for(var i in compared_article){
            if(j <= 10) {
	            elem=document.getElementById('c_'+compared_article[i]);
    	        if(elem){
        	        elem.checked=true;
            	}
            	setCookie('compared_articles['+i+']',compared_article[i],365);
            }else{
	            if(j=10){
	            	alert('Es k�nnen nur maximal 10 Artikel verglichen werden.');
	            	}
            }
            j++;
        }
    }
}