
  var divwindow;
  var frameid;
  
  var ie=document.all;
  var nn6=document.getElementById&&!document.all;
  var isdrag=false;
  var x,y;
  var dobj;

  
  document.write('<div id="divwindow"><span style="display:none"></span></div>')
  
  if(dobj){
	  if(dobj.style.left){
		  document.onmousedown=selectmouse;
		  document.onmouseup=new Function("isdrag=false");
	  }
  }
	function movemouse(e){
	  if (isdrag){
		  if(dobj){
			  if(dobj.style.left){
				  dobj.style.left = nn6 ? (tx + e.clientX - x)+"px" : (tx + event.clientX - x)+"px";
				  dobj.style.top  = nn6 ? (ty + e.clientY - y)+"px" : (ty + event.clientY - y)+"px";
			  }
		  }
	    return false;
	  }
	}
	function selectmouse(e) {
	  var fobj       = nn6 ? e.target : event.srcElement;
	  var topelement = nn6 ? "HTML" : "BODY";
	  
	  while (fobj.tagName != topelement && fobj.id != frameid) {
		if (nn6){
			fobj = fobj.parentNode;
		}else{
			if(fobj.parentElement==null){
				return;
			}else{
				fobj = fobj.parentElement;
			}
		}
	    //fobj = (nn6 ? fobj.parentNode : fobj.parentElement);
	  }
	  
	  //nur wenn fobj.id = frameid wird dragging moeglich
	  if (fobj.id==frameid) {
	    isdrag = true;
	    dobj = fobj;
	    
	    tx = parseInt(dobj.style.left+0);
	    ty = parseInt(dobj.style.top+0);
	    
	    x = nn6 ? e.clientX : event.clientX;
	    y = nn6 ? e.clientY : event.clientY;
	    
	    document.onmousemove=movemouse;
	    return false;
	  }
	}
  
  function gethtml(title,url,width,height){
    var headwidth=(width-4);
    var contentheight=(height-20);
    var whtml='';
    
    whtml='<div id="inline_head" class="in_head" style="width:'+headwidth+'px;z-index:20001;">';
    whtml+=title;
    whtml+='<div id="inline_close" class="in_close" onclick="closeDivWindow()"></div>';
    whtml+='</div>';
    
    whtml+='<div id="inline_content" class="in_content" style="height:'+contentheight+'px;width:'+width+'px;">';
      whtml+='<iframe src="';
      whtml+=url;
      whtml+='"'; 
      whtml+='class="in_content_frame"';
      whtml+='name="inhalt"';
      whtml+='id="in_inhalt">';
      whtml+='</iframe>';
    whtml+='</div>';
    whtml+='</div>';
    return whtml
  }
  
  function closeDivWindow(){
	    var Node = document.getElementById("divwindow");
	    var len = Node.childNodes.length;
	    for(var i = 0; i < len; i++){
	    	if(Node.childNodes[i].id == frameid){
	    		Node.removeChild(Node.childNodes[i]);
	    	}
	     }
	  }

  function createDivWindow(id,title,url,width,height,top,left){
    frameid=id;
    var winobj=document.createElement('div');
    winobj.id=frameid;
    winobj.className='in_main';
    winobj.style.top=top+"px"
    winobj.style.left=left+"px";
    winobj.style.width=width+"px";
    winobj.style.height=height+"px";
    winobj.style.zIndex=20000;
    winobj.innerHTML=gethtml(title,url,width,height);
    if(document.getElementById(id)==null){
      document.getElementById('divwindow').appendChild(winobj);
    }
    divwindow = document.getElementById(frameid);
    divwindow.style.display='block';
    return divwindow;
  }
