$(document).ready(function(){
		
	$(".ui-helper-hidden-accessible").hide();
});

var klickcount = 0;
var autocomplete={

StartFade 	: 50000,
TimeToFade 	: 50000,

oldinput	: new Array(),

selected	: new Array(),
oldselected	: new Array(),
count		: new Array(),
sourceid	: new Array(),
		
search		: true,
searchid	: 0,
submit 		: false,
enter 		: false,
klickcount	: 1,

InitElement:function(inputfield,offset,sourceid){
//	var inputfield = document.getElementById(elementId+'_input');
	this.addEvent(inputfield, 'keyup'	 , autocomplete.myalert);
	this.addEvent(inputfield, 'keydown'  , autocomplete.myalert);
	this.addEvent(inputfield, 'keypress' , autocomplete.myalert);
	this.addEvent(inputfield, 'blur'	 , autocomplete.myalert);
	this.createtextdiv(inputfield,offset);
	inputfield.setAttribute( "autocomplete","off" );
	this.selected[inputfield.id]		=-1;
	this.oldselected[inputfield.id]		=-1;
	this.oldinput[inputfield.id]		='';
	this.count[inputfield.id]			= 0;
	this.sourceid[inputfield.id]		= sourceid;
},

Init:function(elementprefix,offsety,offsetx,sourceid){
	var i = 1;
	var elem;
	var target;

	var offset=new Object();
	offset.x=offsetx;
	offset.y=offsety;
	
	if(elem = document.getElementById(elementprefix+'_input')){
		this.InitElement(elem,offset,sourceid);
		target=elem;
	}
	
	while(elem = document.getElementById(elementprefix+'_'+i+'')){
		this.InitElement(elem,offset,sourceid);//elementprefix+i);
		if(elem = document.getElementById(elementprefix+'_'+i+'_count'+'')){
			this.addEvent(elem, 'keypress' , autocomplete.myalert);
			target=elem;
		}
		i++;
	}
	
	if(target)
		while(target=target.parentNode){
			if(target.tagName){
				if(target.tagName.toUpperCase()=='FORM'){
					this.addEvent(target, 'submit' , autocomplete.myalert);
				}
			}
		}
},

/*
 * Erstellt Div zur Anzeige der Suchtreffer
 */
createtextdiv:function(inputfield,offset){
	var pos=this.getPosition(inputfield);
	document.write('<div style="');
	document.write('position:absolute;');
	document.write('border:1px solid black;');
	document.write('left:'+(pos.x+offset.x)+'px;');
	document.write('top:'+(pos.y+offset.y)+'px;');
	document.write('width:178px;');
	document.write('height:200px;');
	document.write('background-color:#fff;');
	document.write('overflow:auto;');
	document.write('font:13px normal Arial,Verdana,sans-serif;');
	document.write('visibility:hidden;');
	document.write('z-index:1200');
	document.write('" id="'+inputfield.id+'_adiv">');
	document.write('</div>');
},

myalert:function(evt){
	var target;
    evt = (evt) ? evt : ((window.event) ? window.event : "");
	if (evt.target) {
		target = evt.target;
	}else if (evt.srcElement){
		target = evt.srcElement;
	}
	if (target.nodeType == 3) // defeat Safari bug
		target = target.parentNode;

	if (evt.which) {
		var keycode = evt.which;
	} else if (evt.keyCode) {
		var keycode = evt.keyCode;
	}
	
//alert(evt.type+'#'+target+'#'+keycode+'#');
	switch(evt.type){
	case "keyup"	: autocomplete.getComplete(target,keycode);return(false);
		break;
	case "keydown"	: autocomplete.checkKey(target,keycode);
		break;
	case "keypress"	: autocomplete.checkEnter(target,keycode);
		break;
	case "blur"		: setTimeout(function () { autocomplete.fade(target.id,'hidden'); },this.StartFade);
		break;
	case "submit"	: 	
						if(autocomplete.enter){
							autocomplete.enter=false;
							  var browserName=navigator.appName;
							  if (browserName=="Microsoft Internet Explorer"){
							  	/*@cc_on 
							  	if (@_jscript_version <= 5.7)
							  	{
							  		
							  	}else{
									evt.preventDefault();
							  	}
							  	@*/
							  }else{
								evt.preventDefault();
							  }
							return autocomplete.FALSESubmit();
						}
		break;
	}
},

FALSESubmit:function(){
	return false;
},


animateFade:function(target, kind, opa)
{  
  var element = document.getElementById(target);

//  alert(element.id);
  
  if(kind == 'visible'){
	  opa += 0.03; 
	  	if(opa >= 1){
		   try 		   {element.style.setAttribute("visibility", "visible", "false");}
		   catch (em)  {element.style.visibility="visible";}
		}else{
		   element.style.opacity = opa;
		   element.style.filter  = 'alpha(opacity = ' + (opa*100) + ')';
		   setTimeout(function () { autocomplete.animateFade(target,kind,opa);}, 13);
		}
  }else{
	  opa -= 0.03; 
		if(opa <= 0){
		   try 		   {element.style.setAttribute("visibility", "hidden", "false");}
		   catch (em)  {element.style.visibility="hidden";}
		}else{
		   element.style.opacity = opa;
		   element.style.filter = 'alpha(opacity = ' + (opa*100) + ')';
		   setTimeout(function () { autocomplete.animateFade(target,kind,opa);}, 23);
		}
  	}
},

fade:function(target, kind)
{
  var element    = document.getElementById(target+'_adiv');

  if(element.style.visibility != kind){
	  if(kind == 'visible'){
		  try 		{element.style.setAttribute("visibility", "visible", "false");}
		  catch (em)  {element.style.visibility="visible";}
		  element.style.opacity = '0';
		  element.style.filter  = 'alpha(opacity = ' + '0' + ')';
		  setTimeout(function () { autocomplete.animateFade(element.id,kind,0); },33);
	  }else{
		  element.style.opacity = '1';
		  element.style.filter  = 'alpha(opacity = ' + '100' + ')';
		  setTimeout(function () { autocomplete.animateFade(element.id,kind,1); },33);
	  }
  }
},

checkEnter:function(target,keycode){
	switch(keycode){
	case 13 	: 	this.enter=true;
					this.FRSubmit(target);
		break;
	case 9		: //TAB
		break;
	}
},

checkKey:function(target,keycode){
	var adiv = document.getElementById(target.id+'_adiv');
	if(this.count[target.id] > 0){
		switch(keycode){
		case 38		: //keyup
			if(this.selected[target.id] > 0){
				this.selected[target.id]--;
				if(this.selected[target.id] > 14){
					adiv.scrollTop-=13;
				}else{
					adiv.scrollTop+=1;
					adiv.scrollTop-=1;
				}
			}else{
				adiv.scrollTop=0;
			}
			break;
		case 40		: //keydown
			if(this.selected[target.id] < this.count[target.id]-1){
				this.selected[target.id]++;
				if(this.selected[target.id] > 14){
					adiv.scrollTop+=13;
				}else{
					adiv.scrollTop+=1;
					adiv.scrollTop-=1;
				}
			}
			break;
		}

//		setTimeout(function () { autocomplete.fade(target.id,'visible');},0);

		if(this.oldselected[target.id]!=this.selected[target.id]){
			if(this.oldselected[target.id] >= 0 ){
				var alink = document.getElementById(target.id+'alink_'+this.oldselected[target.id]);
				alink.style.backgroundColor='#FFFFFF';
			}
			
			if(this.selected[target.id] >= 0 ){
				var link = document.getElementById(target.id+'alink_'+this.selected[target.id]);
				link.style.backgroundColor='#A0A0A0';
			}
			
			this.oldselected[target.id]=this.selected[target.id];
			target.value=link.innerHTML;
		}
	}
	// return(false);
},

FRSubmit:function(target){
//	alert('submit'+target.id);
	if(!this.submit){
		if(!this.sourceid[target.id]){
			var targetid=target.id;
				if(targetid.match(/.*_count.*/)){
					targetid=targetid.replace(/(\d+)/,Number(targetid.replace(/[^\d]*/g,''))+1);
					targetid=targetid.replace(/_count/,'');
					if(elem=document.getElementById(targetid))
						elem.focus();
				}
				else
//	alert('submit'+target.id);
					while(target=target.parentNode){
						if(target.tagName){
							if(target.tagName.toUpperCase()=='FORM'){
								if(targetid=='searchbutton')
									this.sendStatistic(target);
									target.submit();
							}
						}
					}
		}else{
			if(this.sourceid[target.id]==5){
//				alert(this.sourceid[target.id])
				if(!this.submit){
					this.submit=true;
					var id=this.selected[target.id];
//					alert(id);
					if(id > -1){
						var link = document.getElementById(target.id+'alink_'+id);
//						alert(link.href);
						window.location = link.href;
					}else{
						while(target=target.parentNode){
							if(target.tagName){
								if(target.tagName.toUpperCase()=='FORM'){
//									this.sendStatistic('target');
									target.submit();
								}
							}
						}
					}
				}
			}else{
				document.getElementById(target.id+'_count').focus();
			}
		}
	}
},

sendStatistic:function(target){
	if (typeof wt !== 'undefined') {
		wt.internalSearch = encodeURI($('#quicksearch', $(target).parent()).val());
		wt.sendinfo();
	}
},
getComplete:function(target,keycode){

	var searchid=this.searchid++;
	var sourceid=this.sourceid[target.id];

	if (keycode < 32 || (keycode >= 33 && keycode <= 46) || (keycode >= 112 && keycode <= 123)) {
		if(keycode == 8){
			// setTimeout(function () { autocomplete.fade(target.id,'hidden');},0);
			setTimeout(function () { autocomplete.load('index.html?ACTION=668;NAME=XML;DATAID='+sourceid+';SEARCHID='+searchid+';TEXT=',encodeURIComponent(target.value),target,searchid);},800);
		}
	}else{
		var adiv = document.getElementById(target.id+'_adiv');
		setTimeout(function () { autocomplete.fade(target.id,'visible');},100);
		if((this.oldinput[target.id] != target.value) && (target.value != '') && (target.value.length > 1)){
			setTimeout(function () { autocomplete.load('index.html?ACTION=668;NAME=XML;DATAID='+sourceid+';SEARCHID='+searchid+';TEXT=',encodeURIComponent(target.value),target,searchid);},800);
		}
	}
},

load:function(loadurl,search,element,searchid)
{
  var http = null;
  var url = loadurl;
  this.search=false;
  if(searchid == (this.searchid-1)){
	  try 
	  {
	    http = new XMLHttpRequest();
	    http.open("GET", url+search, true);
	    http.onreadystatechange = loaded;//autocomplete.show(elementid);
	    http.send(null);
	  } 
	  catch (trymicrosoft) 
	  {
	     try 
	     {
	       http = new ActiveXObject("Msxml2.XMLHTTP");
	       http.open("GET", url+search, true);
	       http.onreadystatechange = loaded;//autocomplete.show(elementid);
	       http.send(null);
	     } 
	     catch (othermicrosoft) 
	     {
	       try 
	       {
	         http = new ActiveXObject("Microsoft.XMLHTTP");
	         http.open("GET", url+search, true);
	         http.onreadystatechange = loaded;//autocomplete.show(elementid);
	         http.send(null);
	       } 
	       catch (failed) 
	       {
	         http = false;
//	         alert(othermicrosoft + " , " +failed);
	       }  
	     }
	   }
//	   if(!http)
//	     alert("XMLHttpRequest");
    }
   function loaded()
   {
     if (http.readyState == 4)
         autocomplete.show(element,http.responseXML,search,searchid);//.responseText);
   } 
},

/*
 * Markiert den noch nicht eingegebenen Teil des Suchtreffers.
 * 
 * @elem 	 - Inputfeld
 * @oltinput - Bisher get�tigte Eingabe
 * @newinput - 1. Suchtreffer der in das Suchfeld geschrieben wird
 */
markinput:function(elem,oldinput,newinput){
	elem.value = newinput;
	if(elem.setSelectionRange){
		elem.setSelectionRange(oldinput.length,newinput.length);
	}else{
		var oRange = elem.createTextRange();
		oRange.moveStart("character", oldinput.length);
		oRange.moveEnd("character", newinput.length);
		oRange.select();
		elem.focus();
	}
},

show:function(element,XMLresponse,search,searchid){
	this.selected[element.id] = this.oldselected[element.id] = -1;
	var adiv = document.getElementById(element.id+'_adiv');
//	setTimeout(function () { autocomplete.fade(element.id,'visible');},0);
	
	if(searchid == (this.searchid-1)){
		adiv.innerHTML='';
		var rows = XMLresponse.getElementsByTagName('possible');
		if(rows.length == 0){
			adiv.innerHTML += decodeURIComponent(search);
		}else{
			this.count[element.id] 	   = rows.length;
			this.oldinput[element.id]  = search;
			
			for (var i=0; i<rows.length; i++) {
				var link='index.html';
				if(rows[i].getAttribute('groupid') > 0){
					link+='?ACTION=2;GROUPID='+rows[i].getAttribute('groupid')+';SEARCH='+encodeURIComponent(rows[i].firstChild.data.replace(";",'%3b'));
				}else if(rows[i].getAttribute('articleid') > 0){
					link+='?ACTION=3;ARTICLE='+rows[i].getAttribute('articleid')+';SEARCH='+encodeURIComponent(rows[i].firstChild.data.replace(";",'%3b'));
				}else{
					link+='?ACTION=446;SEARCH='+encodeURIComponent(rows[i].firstChild.data);
				}

				if(element.name != 'SEARCH'){
					adiv.innerHTML +=  '<a onclick="document.getElementById(\''+element.id+'\').value = \''+rows[i].firstChild.data+'\';document.getElementById(\''+element.id+'_count\').focus(); return false" href="'+link+'" id="'+element.id+'alink_'+i+'" style="color:#000;display:block;width:156px;overflow:hidden;text-decoration:none">'+rows[i].firstChild.data+'</a>';				
					
				}else{
					adiv.innerHTML +=  '<a  href="'+link+'" id="'+element.id+'alink_'+i+'" style="color:#000;display:block;width:156px;overflow:hidden;text-decoration:none">'+rows[i].firstChild.data+'</a>';

				}
					
				if((i==0) && (this.sourceid[element.id]==1)){
					this.markinput(element,element.value,document.getElementById(element.id+'alink_'+i).innerHTML);
				}
			}
		}
		this.search=true;
		this.oldselected[element.id] = -1;
	}
},


addEvent:function( obj, type, fn )
{
	if(obj){
	   if (obj.addEventListener) {
	      obj.addEventListener( type, fn, false );
	   } else if (obj.attachEvent) {
	      obj["e"+type+fn] = fn;
	      obj[type+fn] = function() { obj["e"+type+fn]( window.event ); };
	      obj.attachEvent( "on"+type, obj[type+fn] );
	   }
	}
},

getPosition:function(element)
{
  var elem=element;
  var tagname="";
  var x=0;
  var y=0;

  while ( (elem != null) &&
		  (typeof(elem) == "object") &&
		  (typeof(elem.tagName) != "undefined")
		  ){
  	tagname=elem.tagName.toUpperCase();
    if (tagname=="BODY" || elem.id=="m_content" || elem.id=="r_content" || elem.id=="searchdiv" || elem.id=="topnavirow" || elem.id=="pagecontent" || elem.id=="postheader"){
        elem=0;
    }else{
    	y+=elem.offsetTop;     
    	x+=elem.offsetLeft;    
    }
    if (typeof(elem)=="object")
      if (typeof(elem.offsetParent)=="object")
    	  	elem=elem.offsetParent;
  }

  var position=new Object();
  position.x=x;
  position.y=y;

  var browserName=navigator.appName;
  if (browserName=="Microsoft Internet Explorer")
  {
  	/*@cc_on 
  	if (@_jscript_version <= 5.7)
  	{
  		if(document.getElementById("loggedin")){
	  		position.y+=94;
	  		position.x+=3;
  		}else{
	  		position.y+=48;
	  		position.x+=3;
	  	}
  	}
  	@*/
  }
  
  return position;
}
};


// Test!!!!

$(document).ready(function(){

    $('select.makeMeFancy').each(function(j){
        
	// The select element to be replaced:
	//var select = $('select.makeMeFancy');
    var select = $(this);

	var selectBoxContainer = $('<div>',{
		'class'       : 'tzSelect',
		'html'		  : '<div class="selectBox"></div>'
	});

	var dropDown = $('<ul>',{class:'dropDown'});
	var selectBox = selectBoxContainer.find('.selectBox');

	// Looping though the options of the original select element
    
	select.find('option').each(function(i){
		var option = $(this);

		if(i == select.prop('selectedIndex')){
			selectBox.html(option.attr('data-html-text'));
		}

		// As of jQuery 1.4.3 we can access HTML5
		// data attributes with the data() method.

		if(option.data('skip')){
			return true;
		}

		// Creating a dropdown item according to the
		// data-icon and data-html-text HTML5 attributes:

		var li = $('<li>',{
//			html:	'<img src="'+option.data('icon')+'" /><span>'+
//					option.data('html-text')+'</span>'
            'html':	'<span class="l">'+option.attr('data-html-text')+'</span>'+'<span class="r">'+option.data('price-text')+'</span>'
		});

		li.click(function(){

			selectBox.html(option.data('html-text'));
   			dropDown.trigger('hide');

			// When a click occurs, we are also reflecting
			// the change on the original select element:
			select.val(option.val());
            window.location = option.data('url');
            
			return false;
		});

		dropDown.append(li);
	});

	selectBoxContainer.append(dropDown.hide());
	select.hide().after(selectBoxContainer);

	// Binding custom show and hide events on the dropDown:

	dropDown.bind('show',function(){

		if(dropDown.is(':animated')){
			return false;
		}

		selectBox.addClass('expanded');
		dropDown.slideDown();

	}).bind('hide',function(){

		if(dropDown.is(':animated')){
			return false;
		}

		selectBox.removeClass('expanded');
		dropDown.slideUp();

	}).bind('toggle',function(){
		if(selectBox.hasClass('expanded')){
			dropDown.trigger('hide');
		}
		else {
            $('.dropDown').each(function(k){
                $(this).trigger('hide');
            });
            dropDown.trigger('show');
        }
	});

	selectBox.click(function(){
		dropDown.trigger('toggle');
		return false;
	});

	// If we click anywhere on the page, while the
	// dropdown is shown, it is going to be hidden:

	$(document).click(function(){
		dropDown.trigger('hide');
	});
    });
});